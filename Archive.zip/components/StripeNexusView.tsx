import React, { useState, useMemo, useCallback } from 'react';
import yaml from 'js-yaml';

const stripeResourcesYAML = `
striperesources:
  account:
    business_profile:
      mcc: null
      name: null
      product_description: null
      support_address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      support_email: null
      support_phone: null
      support_url: null
      url: null
      minority_owned_business_designation: null
    business_type: null
    capabilities:
      card_payments: active
      transfers: active
    charges_enabled: false
    controller:
      type: account
    country: US
    created: 1234567890
    default_currency: usd
    details_submitted: false
    email: site@stripe.com
    external_accounts:
      data: []
      has_more: false
      object: list
      url: /v1/accounts/acct_1MWlHDJITzLVzkSm/external_accounts
    future_requirements:
      alternatives: []
      current_deadline: null
      currently_due: []
      disabled_reason: null
      errors: []
      eventually_due: []
      past_due: []
      pending_verification: []
    id: acct_1MWlHDJITzLVzkSm
    metadata: {}
    object: account
    payouts_enabled: false
    requirements:
      alternatives: []
      current_deadline: null
      currently_due:
        - business_profile.product_description
        - business_profile.support_phone
        - business_profile.url
        - external_account
        - tos_acceptance.date
        - tos_acceptance.ip
      disabled_reason: requirements.past_due
      errors: []
      eventually_due:
        - business_profile.product_description
        - business_profile.support_phone
        - business_profile.url
        - external_account
        - tos_acceptance.date
        - tos_acceptance.ip
      past_due: []
      pending_verification: []
    settings:
      bacs_debit_payments:
        display_name: null
        service_user_number: null
      branding:
        icon: null
        logo: null
        primary_color: null
        secondary_color: null
      card_issuing:
        tos_acceptance:
          date: null
          ip: null
      card_payments:
        decline_on:
          avs_failure: true
          cvc_failure: true
        statement_descriptor_prefix: null
        statement_descriptor_prefix_kana: null
        statement_descriptor_prefix_kanji: null
      dashboard:
        display_name: null
        timezone: Etc/UTC
      payments:
        statement_descriptor: null
        statement_descriptor_kana: null
        statement_descriptor_kanji: null
        statement_descriptor_prefix_kana: null
        statement_descriptor_prefix_kanji: null
      payouts:
        debit_negative_balances: true
        schedule:
          delay_days: 2
          interval: daily
        statement_descriptor: null
      sepa_debit_payments: {}
    tos_acceptance:
      date: null
      ip: null
      user_agent: null
    type: standard
  account_link:
    created: 1234567890
    expires_at: 1234567890
    object: account_link
    url: >-
      https://rwashburne-manage-mydev.dev.stripe.me/setup/s/acct_1MWlHDJITzLVzkSm/Ep8ZlYAWJPc0
  apple_pay_domain:
    created: 1234567890
    domain_name: example.com
    id: apwc_1MlLi1JITzLVzkSma2iSMoVr
    livemode: true
    object: apple_pay_domain
  application_fee:
    account: acct_1MWlHDJITzLVzkSm
    amount: 100
    amount_refunded: 0
    application: ca_NWOVPPSIVPD11hXgbABn38xeiYlTnzDZ
    balance_transaction: txn_1MlLhiJITzLVzkSm0tDIM70A
    charge: ch_1Mcd6UJITzLVzkSmp1XIBHoW
    created: 1234567890
    currency: usd
    id: fee_1MlLiCJITzLVzkSmRgPvDzIk
    livemode: false
    object: application_fee
    originating_transaction: null
    refunded: false
    refunds:
      data: []
      has_more: false
      object: list
      url: /v1/application_fees/fee_1MlLiCJITzLVzkSmRgPvDzIk/refunds
    fee_source:
      type: charge
  apps.secret:
    created: 1234567890
    expires_at: 1234567890
    id: appsecret_5110QzMIZ0005GiEH1m0419O8KAxCG
    livemode: false
    name: test-secret
    object: apps.secret
    scope:
      type: account
  balance:
    available:
      - amount: 0
        currency: usd
        source_types:
          card: 0
    connect_reserved:
      - amount: 0
        currency: usd
    livemode: false
    object: balance
    pending:
      - amount: 0
        currency: usd
        source_types:
          card: 0
  balance_transaction:
    amount: 100
    available_on: 1234567890
    created: 1234567890
    currency: usd
    description: My First Test Charge (created for API docs)
    exchange_rate: null
    fee: 0
    fee_details: []
    id: txn_1MlLhiJITzLVzkSm0tDIM70A
    net: 100
    object: balance_transaction
    reporting_category: charge
    source: ch_1Mcd6UJITzLVzkSmp1XIBHoW
    status: available
    type: charge
  bank_account:
    account_holder_name: Jane Austen
    account_holder_type: company
    account_type: null
    bank_name: STRIPE TEST BANK
    country: US
    currency: usd
    customer: null
    fingerprint: I1e2zttmxgyFZKaM
    id: ba_1Mcd6nJITzLVzkSm2CZD1tkj
    last4: '3461'
    metadata: {}
    object: bank_account
    routing_number: '110000000'
    status: new
  billing_portal.configuration:
    active: true
    application: null
    business_profile:
      headline: null
      privacy_policy_url: 'https://example.com/privacy'
      terms_of_service_url: 'https://example.com/terms'
    created: 1234567890
    default_return_url: null
    features:
      customer_update:
        allowed_updates:
          - email
          - tax_id
        enabled: true
      invoice_history:
        enabled: true
      payment_method_update:
        enabled: false
        payment_method_configuration: null
      subscription_cancel:
        cancellation_reason:
          enabled: false
          options: []
        enabled: false
        mode: at_period_end
        proration_behavior: none
      subscription_update:
        default_allowed_updates: []
        enabled: false
        proration_behavior: none
        schedule_at_period_end:
          conditions:
            - type: decreasing_item_amount
        trial_update_behavior: end_trial
        billing_cycle_anchor: null
    id: bpc_1MlLiHJITzLVzkSmmFpILKiF
    is_default: true
    livemode: true
    login_page:
      enabled: false
      url: null
    metadata: null
    object: billing_portal.configuration
    updated: 1234567890
    name: null
  billing_portal.session:
    configuration: bpc_1MlLiHJITzLVzkSmUYpn1kRA
    created: 1234567890
    customer: cus_NNNslJKODLsLoG
    flow:
      after_completion:
        hosted_confirmation:
          custom_message: null
        redirect:
          return_url: return_url
        type: hosted_confirmation
      subscription_cancel:
        retention:
          coupon_offer:
            coupon: coupon
          type: coupon_offer
        subscription: subscription
      subscription_update:
        subscription: subscription
      subscription_update_confirm:
        discounts: null
        items:
          - id: null
            price: null
        subscription: subscription
      type: subscription_update
    id: bps_1MlLiHJITzLVzkSm8ZH6SnN2
    livemode: true
    locale: null
    object: billing_portal.session
    on_behalf_of: null
    return_url: 'https://example.com/account'
    url: >-
      https://rwashburne-customer_portal-mydev.dev.stripe.me/session/{SESSION_SECRET}
  capability:
    account: acct_1MWlHDJITzLVzkSm
    future_requirements:
      alternatives: []
      current_deadline: null
      currently_due: []
      disabled_reason: null
      errors: []
      eventually_due: []
      past_due: []
      pending_verification: []
    id: card_payments
    object: capability
    requested: true
    requested_at: 1234567890
    requirements:
      alternatives: []
      current_deadline: null
      currently_due: []
      disabled_reason: null
      errors: []
      eventually_due: []
      past_due: []
      pending_verification: []
    status: inactive
  card:
    address_city: null
    address_country: null
    address_line1: null
    address_line1_check: null
    address_line2: null
    address_state: null
    address_zip: null
    address_zip_check: null
    brand: Visa
    country: US
    customer: null
    cvc_check: pass
    dynamic_last4: null
    exp_month: 8
    exp_year: 2030
    fingerprint: XFO13q66ulrWf0ou
    funding: credit
    id: card_1Mcd6SJITzLVzkSmqkE2eJHO
    last4: '4242'
    metadata: {}
    name: Jenny Rosen
    object: card
    tokenization_method: null
    regulated_status: null
  cash_balance:
    available:
      eur: 10000
    customer: cus_NNNslJKODLsLoG
    livemode: false
    object: cash_balance
    settings:
      reconciliation_mode: automatic
      using_merchant_default: true
  charge:
    amount: 100
    amount_captured: 0
    amount_refunded: 0
    application: null
    application_fee: null
    application_fee_amount: null
    balance_transaction: txn_1MlLhiJITzLVzkSm0tDIM70A
    billing_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      email: null
      name: Jenny Rosen
      phone: null
      tax_id: null
    calculated_statement_descriptor: null
    captured: false
    created: 1234567890
    currency: usd
    customer: null
    description: My First Test Charge (created for API docs)
    disputed: false
    failure_balance_transaction: null
    failure_code: null
    failure_message: null
    fraud_details: {}
    id: ch_1Mcd6UJITzLVzkSmp1XIBHoW
    livemode: false
    metadata: {}
    object: charge
    on_behalf_of: null
    outcome:
      advice_code: null
      network_advice_code: null
      network_decline_code: null
      network_status: null
      reason: null
      seller_message: null
      type: type
    paid: true
    payment_intent: null
    payment_method: card_1Mcd6SJITzLVzkSmqkE2eJHO
    payment_method_details:
      card:
        brand: visa
        checks:
          address_line1_check: null
          address_postal_code_check: null
          cvc_check: pass
        country: US
        exp_month: 8
        exp_year: 2030
        fingerprint: XFO13q66ulrWf0ou
        funding: credit
        installments:
          plan:
            count: null
            interval: null
            type: fixed_count
        last4: '4242'
        mandate: null
        network: visa
        three_d_secure:
          authentication_flow: null
          electronic_commerce_indicator: null
          exemption_indicator: null
          result: null
          result_reason: null
          transaction_id: null
          version: null
        wallet:
          dynamic_last4: null
          type: link
        amount_authorized: null
        authorization_code: null
        network_transaction_id: null
        regulated_status: null
      type: card
    receipt_email: null
    receipt_number: null
    receipt_url: >-
      https://rwashburne-manage-mydev.dev.stripe.me/receipts/payment/CAcaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKNr-vqAGMga56OxYPmU6LCIJCzDVSp5Ad3U9fZNleQoPNZ-HObHtPnsz8U55_1KOofBmEmAK5jBlWIYZ
    refunded: false
    refunds:
      data: []
      has_more: false
      object: list
      url: /v1/charges/ch_1Mcd6UJITzLVzkSmp1XIBHoW/refunds
    review: null
    shipping: {}
    source_transfer: null
    statement_descriptor: null
    statement_descriptor_suffix: null
    status: succeeded
    transfer_data:
      amount: null
      destination:
        id: obj_123
        object: account
    transfer_group: null
    source:
      allow_redisplay: null
      amount: null
      client_secret: client_secret
      created: 1028554472
      currency: null
      flow: flow
      id: obj_123
      livemode: true
      metadata: null
      object: source
      owner:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: null
        phone: null
        verified_address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        verified_email: null
        verified_name: null
        verified_phone: null
      statement_descriptor: null
      status: status
      type: ideal
      usage: null
  checkout.session:
    after_expiration:
      recovery:
        allow_promotion_codes: true
        enabled: true
        expires_at: null
        url: null
    allow_promotion_codes: null
    amount_subtotal: null
    amount_total: null
    automatic_tax:
      enabled: false
      status: null
      liability:
        type: account
      provider: null
    billing_address_collection: null
    cancel_url: 'https://example.com/cancel'
    client_reference_id: null
    consent:
      promotions: null
      terms_of_service: null
    consent_collection:
      payment_method_reuse_agreement:
        position: hidden
      promotions: null
      terms_of_service: null
    created: 1234567890
    currency: null
    custom_fields: []
    custom_text:
      shipping_address:
        message: message
      submit:
        message: message
      after_submit:
        message: message
      terms_of_service_acceptance:
        message: message
    customer: null
    customer_creation: null
    customer_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      email: example@example.com
      name: null
      phone: null
      tax_exempt: none
      tax_ids: null
      business_name: null
      individual_name: null
    customer_email: null
    expires_at: 1234567890
    id: cs_test_a1P5YYluaNII2Sw4YvDcqWDVcCaEF88dgjX1R52zahnP5GOEowMj42pzSq
    invoice: null
    invoice_creation:
      enabled: true
      invoice_data:
        account_tax_ids: null
        custom_fields: null
        description: null
        footer: null
        issuer:
          type: account
        metadata: null
        rendering_options:
          amount_tax_display: null
          template: null
    livemode: false
    locale: null
    metadata: {}
    mode: payment
    object: checkout.session
    payment_intent: pi_1Mcd6XJITzLVzkSmwOxqskee
    payment_link: null
    payment_method_collection: null
    payment_method_options: {}
    payment_method_types:
      - card
    payment_status: unpaid
    phone_number_collection:
      enabled: false
    recovered_from: null
    setup_intent: null
    shipping_address_collection:
      allowed_countries:
        - SC
    shipping_cost:
      amount_subtotal: 1555417355
      amount_tax: 1424534716
      amount_total: 1117121693
      shipping_rate: null
    shipping_options: []
    status: open
    submit_type: null
    subscription: null
    success_url: 'https://example.com/success'
    total_details:
      amount_discount: 406046392
      amount_shipping: null
      amount_tax: 1424534716
    url: >-
      https://checkout.stripe.com/pay/c/cs_test_a1P5YYluaNII2Sw4YvDcqWDVcCaEF88dgjX1R52zahnP5GOEowMj42pzSq
    adaptive_pricing:
      enabled: true
    client_secret: null
    collected_information:
      shipping_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        name: name
      business_name: null
      individual_name: null
    discounts: null
    payment_method_configuration_details:
      id: obj_123
      parent: null
    permissions:
      update_shipping_details: null
    saved_payment_method_options:
      allow_redisplay_filters: null
      payment_method_remove: null
      payment_method_save: null
    ui_mode: null
    wallet_options: {}
    origin_context: null
    currency_conversion:
      amount_subtotal: 1555417355
      amount_total: 1117121693
      fx_rate: '291452898'
      source_currency: usd
  country_spec:
    default_currency: usd
    id: US
    object: country_spec
    supported_bank_account_currencies:
      usd:
        - US
    supported_payment_currencies:
      - ...
      - aed
      - afn
      - usd
    supported_payment_methods:
      - ach
      - card
      - stripe
    supported_transfer_countries:
      - AE
      - AG
      - AL
      - AM
      - AO
      - AR
      - AT
      - AU
      - AZ
      - BA
      - BD
      - BE
      - BG
      - BH
      - BJ
      - BN
      - BO
      - BS
      - BT
      - BW
      - CA
      - CH
      - CI
      - CL
      - CO
      - CR
      - CY
      - CZ
      - DE
      - DK
      - DO
      - DZ
      - EC
      - EE
      - EG
      - ES
      - ET
      - FI
      - FR
      - GA
      - GB
      - GH
      - GM
      - GR
      - GT
      - GY
      - HK
      - HR
      - HU
      - ID
      - IE
      - IL
      - IS
      - IT
      - JM
      - JO
      - JP
      - KE
      - KH
      - KR
      - KW
      - LA
      - LC
      - LI
      - LK
      - LT
      - LU
      - LV
      - MA
      - MC
      - MD
      - MG
      - MK
      - MN
      - MO
      - MT
      - MU
      - MX
      - MY
      - MZ
      - NA
      - NE
      - NG
      - NL
      - 'NO'
      - NZ
      - OM
      - PA
      - PE
      - PH
      - PL
      - PT
      - PY
      - QA
      - RO
      - RS
      - RW
      - SA
      - SE
      - SG
      - SI
      - SK
      - SM
      - SN
      - SV
      - TH
      - TN
      - TR
      - TT
      - TW
      - TZ
      - US
      - UY
      - UZ
      - VN
      - ZA
    verification_fields:
      company:
        additional: []
        minimum:
          - business_profile.mcc
          - business_profile.url
          - business_type
          - company.address.city
          - company.address.line1
          - company.address.postal_code
          - company.address.state
          - company.name
          - company.owners_provided
          - company.phone
          - company.tax_id
          - external_account
          - owners.address.city
          - owners.address.line1
          - owners.address.postal_code
          - owners.address.state
          - owners.dob.day
          - owners.dob.month
          - owners.dob.year
          - owners.email
          - owners.first_name
          - owners.id_number
          - owners.last_name
          - owners.phone
          - owners.ssn_last_4
          - owners.verification.document
          - representative.address.city
          - representative.address.line1
          - representative.address.postal_code
          - representative.address.state
          - representative.dob.day
          - representative.dob.month
          - representative.dob.year
          - representative.email
          - representative.first_name
          - representative.id_number
          - representative.last_name
          - representative.phone
          - representative.relationship.executive
          - representative.relationship.title
          - representative.ssn_last_4
          - representative.verification.document
          - tos_acceptance.date
          - tos_acceptance.ip
      individual:
        additional: []
        minimum:
          - business_profile.mcc
          - business_profile.url
          - business_type
          - external_account
          - individual.address.city
          - individual.address.line1
          - individual.address.postal_code
          - individual.address.state
          - individual.dob.day
          - individual.dob.month
          - individual.dob.year
          - individual.email
          - individual.first_name
          - individual.id_number
          - individual.last_name
          - individual.phone
          - individual.ssn_last_4
          - individual.verification.document
          - tos_acceptance.date
          - tos_acceptance.ip
  coupon:
    amount_off: null
    created: 1234567890
    currency: usd
    duration: repeating
    duration_in_months: 3
    id: Z4OV52SU
    livemode: false
    max_redemptions: null
    metadata: {}
    name: 25.5% off
    object: coupon
    percent_off: 25.5
    redeem_by: 1234567890
    times_redeemed: 0
    valid: true
  credit_note:
    amount: 1690
    amount_shipping: 0
    created: 1234567890
    currency: usd
    customer: cus_NNNslJKODLsLoG
    customer_balance_transaction: null
    discount_amount: 0
    discount_amounts: []
    id: cn_1MlLiIJITzLVzkSmnWRQrDBf
    invoice: in_1MlLiHJITzLVzkSmDEv4Nqiq
    lines:
      data:
        - amount: 1190
          description: My First Invoice Item (created for API docs)
          discount_amount: 0
          discount_amounts: []
          id: cnli_1MlLiIJITzLVzkSmHScfIjOc
          invoice_line_item: il_1MlLiHJITzLVzkSmOrWAtod5
          livemode: false
          object: credit_note_line_item
          quantity: 1
          tax_rates:
            - active: true
              country: DE
              created: 1678753657
              description: VAT Germany
              display_name: VAT
              id: txr_1MlLiHJITzLVzkSm3d4Zc9NE
              inclusive: false
              jurisdiction: DE
              livemode: false
              metadata: {}
              object: tax_rate
              percentage: 19
              state: null
              tax_type: vat
              effective_percentage: null
              flat_amount:
                amount: 1413853096
                currency: currency
              jurisdiction_level: null
              rate_type: null
          type: invoice_line_item
          unit_amount: null
          unit_amount_decimal: null
          pretax_credit_amounts:
            - amount: 1413853096
              type: credit_balance_transaction
          taxes: null
        - amount: 500
          description: Service credit
          discount_amount: 0
          discount_amounts: []
          id: cnli_1MlLiIJITzLVzkSm5LIWS0zP
          livemode: false
          object: credit_note_line_item
          quantity: 1
          tax_rates: []
          type: custom_line_item
          unit_amount: 500
          unit_amount_decimal: '500'
          pretax_credit_amounts:
            - amount: 1413853096
              type: credit_balance_transaction
          taxes: null
      has_more: false
      object: list
      url: /v1/credit_notes/cn_1MlLiIJITzLVzkSmnWRQrDBf/lines
    livemode: false
    memo: null
    metadata: {}
    number: ABCD-1234-CN-01
    object: credit_note
    out_of_band_amount: null
    pdf: >-
      https://rwashburne-manage-mydev.dev.stripe.me/credit_notes/acct_1MWlHDJITzLVzkSm/cnst_123456789/pdf?s=ap
    shipping_cost:
      amount_subtotal: 1555417355
      amount_tax: 1424534716
      amount_total: 1117121693
      shipping_rate: null
    status: issued
    subtotal: 1690
    subtotal_excluding_tax: 1690
    total: 1690
    total_excluding_tax: null
    type: pre_payment
    voided_at: 1234567890
    effective_at: null
    post_payment_amount: 1355257296
    pre_payment_amount: 251024947
    pretax_credit_amounts:
      - amount: 1413853096
        type: credit_balance_transaction
    refunds:
      - amount_refunded: 1387154914
        refund:
          amount: 1413853096
          balance_transaction: null
          charge: null
          created: 1028554472
          currency: currency
          id: obj_123
          metadata: null
          object: refund
          payment_intent: null
          reason: null
          receipt_number: null
          source_transfer_reversal: null
          status: null
          transfer_reversal: null
        payment_record_refund:
          payment_record: payment_record
          refund_group: refund_group
        type: null
    total_taxes: null
    reason: null
  credit_note_line_item:
    amount: 1000
    description: My First Invoice Item (created for API docs)
    discount_amount: 0
    discount_amounts: []
    id: cnli_1MlLiIJITzLVzkSmDwzjUkgF
    invoice_line_item: il_1MlLiHJITzLVzkSm6Gg3zoV0
    livemode: false
    object: credit_note_line_item
    quantity: 1
    tax_rates: []
    type: invoice_line_item
    unit_amount: null
    unit_amount_decimal: null
    pretax_credit_amounts:
      - amount: 1413853096
        type: credit_balance_transaction
    taxes: null
  customer:
    address:
      city: null
      country: null
      line1: null
      line2: null
      postal_code: null
      state: null
    balance: 0
    created: 1234567890
    currency: usd
    default_source: null
    delinquent: false
    description: null
    discount:
      checkout_session: null
      customer: null
      end: null
      id: obj_123
      invoice: null
      invoice_item: null
      object: discount
      promotion_code: null
      start: 109757538
      subscription: null
      subscription_item: null
      source:
        coupon: null
        type: coupon
    email: null
    id: cus_NNNslJKODLsLoG
    invoice_prefix: 1A66DA4
    invoice_settings:
      custom_fields: null
      default_payment_method: null
      footer: null
      rendering_options:
        amount_tax_display: null
        template: null
    livemode: false
    metadata: {}
    name: null
    next_invoice_sequence: 1
    object: customer
    phone: null
    preferred_locales: []
    shipping: {}
    tax_exempt: none
    test_clock: null
  customer_balance_transaction:
    amount: -500
    created: 1234567890
    credit_note: null
    currency: usd
    customer: cus_NNNslJKODLsLoG
    description: null
    ending_balance: -500
    id: cbtxn_1MlLi6JITzLVzkSmTSG1zk0i
    invoice: null
    livemode: false
    metadata: null
    object: customer_balance_transaction
    type: adjustment
    checkout_session: null
  customer_cash_balance_transaction:
    created: 1234567890
    currency: eur
    customer: cus_NNNslJKODLsLoG
    ending_balance: 10000
    funded:
      bank_transfer:
        eu_bank_transfer:
          bic: BANKDEAAXXX
          iban_last4: '7089'
          sender_name: Sample Business GmbH
        reference: Payment for Invoice 1A66DA4-155
        type: eu_bank_transfer
    id: ccsbtxn_1MlLi6JITzLVzkSmVRcwxIo4
    livemode: false
    net_amount: 5000
    object: customer_cash_balance_transaction
    type: funded
  deleted_account:
    deleted: true
    id: acct_1MWlHDJITzLVzkSm
    object: account
  deleted_apple_pay_domain:
    deleted: true
    id: apwc_1MlLi1JITzLVzkSma2iSMoVr
    object: apple_pay_domain
  deleted_coupon:
    deleted: true
    id: Z4OV52SU
    object: coupon
  deleted_customer:
    deleted: true
    id: cus_NNNslJKODLsLoG
    object: customer
  deleted_discount:
    deleted: true
    id: ''
    object: discount
    start: 1234567890
    checkout_session: null
    customer: null
    invoice: null
    invoice_item: null
    promotion_code: null
    subscription: null
    subscription_item: null
    source:
      coupon: null
      type: coupon
  deleted_external_account:
    deleted: true
    id: ba_1Mcd6nJITzLVzkSm2CZD1tkj
    object: bank_account
  deleted_invoice:
    deleted: true
    id: in_1MlLhvJITzLVzkSmcKw0tIgl
    object: invoice
  deleted_invoiceitem:
    deleted: true
    id: ii_1MlLi6JITzLVzkSmDouPGUDT
    object: invoiceitem
  deleted_payment_source:
    deleted: true
    id: ba_1Mcd6nJITzLVzkSm2CZD1tkj
    object: bank_account
  deleted_person:
    deleted: true
    id: person_1MlLiHJITzLVzkSmB4pg1uK9
    object: person
  deleted_plan:
    deleted: true
    id: price_1Mcd6ZJITzLVzkSmwd29pdd3
    object: plan
  deleted_product:
    deleted: true
    id: prod_NNNsbcqAqCJrj2
    object: product
  deleted_radar.value_list:
    deleted: true
    id: rsl_1MlLiGJITzLVzkSmi6kJ5coN
    object: radar.value_list
  deleted_radar.value_list_item:
    deleted: true
    id: rsli_1MlLiGJITzLVzkSmBdrq4Qmw
    object: radar.value_list_item
  deleted_subscription_item:
    deleted: true
    id: si_NWOVMvXVc2SbwK
    object: subscription_item
  deleted_tax_id:
    deleted: true
    id: txi_1MlLiHJITzLVzkSmi1opmyET
    object: tax_id
  deleted_terminal.configuration:
    deleted: true
    id: tmc_ElVUAjF8xXG3hj
    object: terminal.configuration
  deleted_terminal.location:
    deleted: true
    id: tml_cKQQfm6UGarpNRJRxXpzca4i
    object: terminal.location
  deleted_terminal.reader:
    deleted: true
    id: tmr_cKxInTQKOxDTvasletECzYvQ
    object: terminal.reader
  deleted_test_helpers.test_clock:
    deleted: true
    id: clock_1MlLiAJITzLVzkSmVBT841xQ
    object: test_helpers.test_clock
  deleted_webhook_endpoint:
    deleted: true
    id: we_1MlLiDJITzLVzkSm0QU7AnxQ
    object: webhook_endpoint
  discount:
    checkout_session: null
    customer: cus_NNNslJKODLsLoG
    end: 1234567890
    id: di_1MlLiAJITzLVzkSmNzEFTVSb
    invoice: null
    invoice_item: null
    object: discount
    promotion_code: null
    start: 1234567890
    subscription: null
    subscription_item: null
    source:
      coupon: null
      type: coupon
  dispute:
    amount: 1000
    balance_transactions: []
    charge: ch_1Mcd6UJITzLVzkSmp1XIBHoW
    created: 1234567890
    currency: usd
    evidence:
      access_activity_log: null
      billing_address: null
      cancellation_policy: null
      cancellation_policy_disclosure: null
      cancellation_rebuttal: null
      customer_communication: null
      customer_email_address: null
      customer_name: null
      customer_purchase_ip: null
      customer_signature: null
      duplicate_charge_documentation: null
      duplicate_charge_explanation: null
      duplicate_charge_id: null
      product_description: null
      receipt: null
      refund_policy: null
      refund_policy_disclosure: null
      refund_refusal_explanation: null
      service_date: null
      service_documentation: null
      shipping_address: null
      shipping_carrier: null
      shipping_date: null
      shipping_documentation: null
      shipping_tracking_number: null
      uncategorized_file: null
      uncategorized_text: null
      enhanced_evidence: {}
    evidence_details:
      due_by: 1680479999
      has_evidence: false
      past_due: false
      submission_count: 0
      enhanced_eligibility: {}
    id: dp_1MlLi1JITzLVzkSmdqrdx0Ir
    is_charge_refundable: true
    livemode: false
    metadata: {}
    object: dispute
    payment_intent: null
    reason: general
    status: warning_needs_response
    enhanced_eligibility_types:
      - visa_compelling_evidence_3
  ephemeral_key:
    created: 1234567890
    expires: 1234567890
    id: ephkey_1MlLiHJITzLVzkSmzwMnAzon
    livemode: false
    object: ephemeral_key
  event:
    api_version: null
    created: 1234567890
    data:
      object:
        active: true
        aggregate_usage: null
        amount: 2000
        amount_decimal: '2000'
        billing_scheme: per_unit
        created: 1676675559
        currency: usd
        id: price_1Mcd6ZJITzLVzkSmwd29pdd3
        interval: month
        interval_count: 1
        livemode: false
        metadata: {}
        nickname: null
        object: plan
        product: prod_NNNsbcqAqCJrj2
        tiers_mode: null
        transform_usage: null
        trial_period_days: null
        usage_type: licensed
    id: evt_1MlLiDJITzLVzkSmHhzJOLbM
    livemode: false
    object: event
    pending_webhooks: 0
    request:
      id: null
      idempotency_key: null
    type: plan.created
  exchange_rate:
    id: rate_7573642d636164
    object: exchange_rate
    rates: {}
  external_account:
    account_holder_name: Jane Austen
    account_holder_type: company
    account_type: null
    bank_name: STRIPE TEST BANK
    country: US
    currency: usd
    customer: null
    fingerprint: I1e2zttmxgyFZKaM
    id: ba_1Mcd6nJITzLVzkSm2CZD1tkj
    last4: '3461'
    metadata: {}
    object: bank_account
    routing_number: '110000000'
    status: new
  fee_refund:
    amount: 100
    balance_transaction: null
    created: 1234567890
    currency: usd
    fee: fee_1MlLiCJITzLVzkSmRgPvDzIk
    id: fr_1MlLiCJITzLVzkSmdm0wxqhZ
    metadata: {}
    object: fee_refund
  file:
    created: 1234567890
    expires_at: 1234567890
    filename: file_1Mcd6lJITzLVzkSmBrhnMBIc
    id: file_1Mcd6lJITzLVzkSmBrhnMBIc
    links:
      data:
        - created: 1678313590
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1MjVEQJITzLVzkSmhoKUNvEL
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3RfNDNCMGlNbkN4OFg0UEtpcFI0ZlBkbzRw00eBTPZOMY
        - created: 1678130857
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1Mijh7JITzLVzkSmNfJLomIO
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3RfdFdmVmZRRVhsMFVpc3Z0eFJ5b1hZMDlx00WT2Wdgbp
        - created: 1677887967
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1MhiVXJITzLVzkSm6Dq9g1cr
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3RfdG5KUDJpQk52U3Y1bG90a3BnQUxqM3Vp00Yptx0n4x
        - created: 1677614580
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1MgZO4JITzLVzkSmYUHx9UWJ
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3RfZWZkVktQWHVUUjZZV25POE5iREZCVlZ500XpIZUgMV
        - created: 1677613823
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1MgZBrJITzLVzkSmkEgJTIGP
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3Rfb1ZCRnV1cHZPM29LYVJraFRYd2Z0OTVy00iOOL1TOk
        - created: 1677612663
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1MgYt9JITzLVzkSmeDM5uAU9
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3Rfa3BKREJaN1JGdGR2Z2hyMnptMzBjeEc000tIWhh2jh
        - created: 1677018025
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1Me4CDJITzLVzkSmG6l1wouM
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3RfeVh4b2NKaVdEa2NyN2lQbG5CbUh0dk8500MxdWafoC
        - created: 1676675571
          expired: false
          expires_at: null
          file: file_1Mcd6lJITzLVzkSmBrhnMBIc
          id: link_1Mcd6lJITzLVzkSmMdO1GZOy
          livemode: false
          metadata: {}
          object: file_link
          url: >-
            https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3RfaXpqN2phREpMZ3dIMlVJQUJ0ejRlNkxw00pNRDCFVW
      has_more: false
      object: list
      url: /v1/file_links?file=file_1Mcd6lJITzLVzkSmBrhnMBIc
    object: file
    purpose: dispute_evidence
    size: 9863
    title: null
    type: png
    url: >-
      https://rwashburne-upload-mydev.dev.stripe.me/v1/files/file_1Mcd6lJITzLVzkSmBrhnMBIc/contents
  file_link:
    created: 1234567890
    expired: false
    expires_at: 1234567890
    file: file_1Mcd6lJITzLVzkSmBrhnMBIc
    id: link_1MlLiHJITzLVzkSmg933O2co
    livemode: false
    metadata: {}
    object: file_link
    url: >-
      https://rwashburne-upload-mydev.dev.stripe.me/links/MDB8YWNjdF8xTVdsSERKSVR6TFZ6a1NtfGZsX3Rlc3Rfb3dFdjR5dVFQelMwdzZ6NzFvYTRrVW5N00Jk7QguH6
  financial_connections.account:
    account_holder:
      customer: cus_NNNslJKODLsLoG
      type: customer
    balance:
      as_of: 93102340
      current:
        undefined: 1126940025
      type: cash
    balance_refresh:
      last_attempted_at: 1981828143
      next_refresh_available_at: null
      status: failed
    category: cash
    created: 1234567890
    display_name: Sample Checking Account
    id: fca_1MlLiIJITzLVzkSmdzRadyct
    institution_name: StripeBank
    last4: '6789'
    livemode: false
    object: financial_connections.account
    ownership: null
    ownership_refresh:
      last_attempted_at: 1981828143
      next_refresh_available_at: null
      status: failed
    permissions: []
    status: active
    subcategory: checking
    supported_payment_method_types:
      - us_bank_account
    subscriptions: null
    transaction_refresh:
      id: obj_123
      last_attempted_at: 1981828143
      next_refresh_available_at: null
      status: failed
    account_numbers: null
  financial_connections.account_owner:
    email: nobody+janesmith@stripe.com
    id: fcaown_1MlLiIJITzLVzkSm3NJZ94Jt
    name: Jane Smith
    object: financial_connections.account_owner
    ownership: fcaowns_1MlLiIJITzLVzkSmJHcKmwIL
    phone: +1 555-555-5555
    raw_address: '123 Main Street, Everytown USA'
    refreshed_at: 1234567890
  financial_connections.session:
    account_holder:
      customer: cus_NNNslJKODLsLoG
      type: customer
    accounts:
      data: []
      has_more: false
      object: list
      url: /v1/financial_connections/accounts
    client_secret: fcsess_..._secret_...
    id: fcsess_1MlLiIJITzLVzkSmGXQM2wtP
    livemode: false
    object: financial_connections.session
    permissions:
      - balances
      - payment_method
    prefetch: null
  funding_instructions:
    bank_transfer:
      country: DE
      financial_addresses:
        - iban:
            account_holder_name: Stripe Technology Europe Limited
            bic: SXPYDEHH
            country: DE
            iban: DE00000000000000000001
            account_holder_address:
              city: null
              country: null
              line1: null
              line2: null
              postal_code: null
              state: null
            bank_address:
              city: null
              country: null
              line1: null
              line2: null
              postal_code: null
              state: null
          supported_networks:
            - sepa
          type: iban
      type: eu_bank_transfer
    currency: eur
    funding_type: bank_transfer
    livemode: false
    object: funding_instructions
  identity.verification_report:
    created: 1234567890
    document:
      address:
        city: San Francisco
        country: US
        line1: 1234 Main St.
        state: CA
        line2: null
        postal_code: null
      error:
        code: null
        reason: null
      expiration_date:
        day: 1
        month: 12
        year: 2025
      files:
        - file_NWOV2MoM5XTbveA96C1vboPt
        - file_NWOVTpKqMOyf5KVCJkNKnnHn
      first_name: Jenny
      issued_date:
        day: 1
        month: 12
        year: 2020
      issuing_country: US
      last_name: Rosen
      status: verified
      type: driving_license
    id: vr_1MlLiIJITzLVzkSmXm2kbOyG
    livemode: false
    object: identity.verification_report
    options:
      document: {}
    type: document
    verification_session: vs_NWOV3nJBiY3XZahmfEbL86ED
    client_reference_id: null
  identity.verification_session:
    client_secret: null
    created: 1234567890
    id: vs_1MlLiIJITzLVzkSmXOIbTTQ7
    last_error:
      code: null
      reason: null
    last_verification_report: vr_NWOVVPm6heOhwu1lJmFFri3N
    livemode: false
    metadata: {}
    object: identity.verification_session
    options:
      document:
        require_matching_selfie: true
    redaction:
      status: processing
    status: verified
    type: document
    url: null
    client_reference_id: null
    related_customer: null
  invoice:
    account_country: US
    account_name: null
    account_tax_ids: null
    amount_due: 1000
    amount_paid: 0
    amount_remaining: 1000
    amount_shipping: 0
    application: null
    attempt_count: 0
    attempted: false
    auto_advance: true
    automatic_tax:
      enabled: false
      status: null
      disabled_reason: null
      liability:
        type: account
      provider: null
    billing_reason: manual
    collection_method: charge_automatically
    created: 1234567890
    currency: usd
    custom_fields: null
    customer: cus_NNNslJKODLsLoG
    customer_address:
      city: null
      country: null
      line1: null
      line2: null
      postal_code: null
      state: null
    customer_email: null
    customer_name: null
    customer_phone: null
    customer_shipping: {}
    customer_tax_exempt: none
    customer_tax_ids: []
    default_payment_method: null
    default_source: null
    default_tax_rates: []
    description: null
    discounts: []
    due_date: 1234567890
    ending_balance: null
    footer: null
    from_invoice:
      action: action
      invoice: invoice
    hosted_invoice_url: null
    id: in_1MlLhvJITzLVzkSmcKw0tIgl
    invoice_pdf: null
    last_finalization_error:
      type: idempotency_error
    latest_revision: null
    lines:
      data:
        - amount: 1000
          currency: usd
          description: My First Invoice Item (created for API docs)
          discount_amounts: []
          discountable: true
          discounts: []
          id: il_1MlLhmJITzLVzkSm90klW90i
          livemode: false
          metadata: {}
          object: line_item
          period:
            end: 1678753626
            start: 1678753626
          quantity: 1
          subscription: null
          invoice: null
          parent:
            invoice_item_details:
              invoice_item: invoice_item
              proration: true
              proration_details:
                credited_items:
                  invoice: invoice
                  invoice_line_items:
                    - invoice_line_items
              subscription: null
            subscription_item_details:
              invoice_item: null
              proration: true
              proration_details:
                credited_items:
                  invoice: invoice
                  invoice_line_items:
                    - invoice_line_items
              subscription: null
              subscription_item: subscription_item
            type: invoice_item_details
          pretax_credit_amounts: null
          pricing:
            type: price_details
            unit_amount_decimal: null
          taxes: null
      has_more: false
      object: list
      url: /v1/invoices/in_1MlLhvJITzLVzkSmcKw0tIgl/lines
    livemode: false
    metadata: {}
    next_payment_attempt: 1234567890
    number: null
    object: invoice
    on_behalf_of: null
    payment_settings:
      default_mandate: null
      payment_method_options:
        acss_debit: {}
        bancontact:
          preferred_language: fr
        card:
          request_three_d_secure: null
        customer_balance:
          funding_type: null
        konbini: {}
        sepa_debit: {}
        us_bank_account: {}
      payment_method_types: null
    period_end: 1234567890
    period_start: 1234567890
    post_payment_credit_notes_amount: 0
    pre_payment_credit_notes_amount: 0
    receipt_number: null
    shipping_cost:
      amount_subtotal: 1555417355
      amount_tax: 1424534716
      amount_total: 1117121693
      shipping_rate: null
    shipping_details: {}
    starting_balance: 0
    statement_descriptor: null
    status: draft
    status_transitions:
      finalized_at: null
      marked_uncollectible_at: null
      paid_at: null
      voided_at: null
    subscription: null
    subtotal: 1000
    subtotal_excluding_tax: 1000
    test_clock: null
    total: 1000
    total_discount_amounts: []
    total_excluding_tax: 1000
    webhooks_delivered_at: 1234567890
    amount_overpaid: 149300825
    automatically_finalizes_at: null
    effective_at: null
    issuer:
      type: account
    parent:
      quote_details:
        quote: quote
      subscription_details:
        metadata: null
        subscription: subscription
      type: quote_details
    rendering:
      amount_tax_display: null
      pdf:
        page_size: null
      template: null
      template_version: null
    total_pretax_credit_amounts: null
    total_taxes: null
  invoiceitem:
    amount: 1000
    currency: usd
    customer: cus_NNNslJKODLsLoG
    date: 1234567890
    description: My First Invoice Item (created for API docs)
    discountable: true
    discounts: []
    id: ii_1MlLi6JITzLVzkSmDouPGUDT
    invoice: null
    livemode: false
    metadata: {}
    object: invoiceitem
    period:
      end: 1678753646
      start: 1678753646
    proration: false
    quantity: 1
    tax_rates: []
    test_clock: null
    parent:
      subscription_details:
        subscription: subscription
      type: subscription_details
    pricing:
      type: price_details
      unit_amount_decimal: null
    net_amount: 708769478
  issuing.authorization:
    amount: 0
    amount_details:
      atm_fee: null
      cashback_amount: null
    approved: true
    authorization_method: keyed_in
    balance_transactions: []
    card:
      brand: Visa
      cancellation_reason: null
      cardholder:
        billing:
          address:
            city: Beverly Hills
            country: US
            line1: 123 Fake St
            line2: Apt 3
            postal_code: '90210'
            state: CA
        company:
          tax_id_provided: true
        created: 1676675570
        email: jenny@example.com
        id: ich_1Mcd6kJITzLVzkSmsPNd4Aor
        individual:
          dob:
            day: null
            month: null
            year: null
          first_name: null
          last_name: null
          verification:
            document:
              back: null
              front: null
        livemode: false
        metadata: {}
        name: Jenny Rosen
        object: issuing.cardholder
        phone_number: '+18008675309'
        requirements:
          disabled_reason: null
          past_due: []
        spending_controls:
          allowed_categories: []
          blocked_categories: []
          spending_limits: []
          spending_limits_currency: null
          allowed_merchant_countries: null
          blocked_merchant_countries: null
        status: active
        type: individual
        preferred_locales: null
      created: 1678753656
      currency: usd
      exp_month: 8
      exp_year: 2030
      id: ic_1MlLiGJITzLVzkSmNmKqbF30
      last4: '4242'
      livemode: false
      metadata: {}
      object: issuing.card
      replaced_by: null
      replacement_for: null
      replacement_reason: null
      shipping:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        address_validation:
          mode: normalization_only
          normalized_address:
            city: null
            country: null
            line1: null
            line2: null
            postal_code: null
            state: null
          result: null
        carrier: null
        customs:
          eori_number: null
        eta: null
        name: name
        phone_number: null
        require_signature: null
        service: express
        status: null
        tracking_number: null
        tracking_url: null
        type: bulk
      spending_controls:
        allowed_categories: null
        blocked_categories: null
        spending_limits: []
        spending_limits_currency: null
        allowed_merchant_countries: null
        blocked_merchant_countries: null
      status: active
      type: physical
      wallets:
        apple_pay:
          eligible: true
          ineligible_reason: null
        google_pay:
          eligible: true
          ineligible_reason: null
        primary_account_identifier: null
      personalization_design: null
      second_line: null
      latest_fraud_warning:
        started_at: null
        type: null
    cardholder: null
    created: 1234567890
    currency: usd
    id: iauth_1MlLiGJITzLVzkSmqSJmhz6r
    livemode: false
    merchant_amount: 0
    merchant_currency: usd
    merchant_data:
      category: taxicabs_limousines
      category_code: '4121'
      city: San Francisco
      country: US
      name: Rocket Rides
      network_id: '1234567890'
      postal_code: '94107'
      state: CA
      tax_id: null
      terminal_id: null
      url: null
    metadata: {}
    network_data:
      acquiring_institution_id: null
      system_trace_audit_number: null
      transaction_id: null
    object: issuing.authorization
    pending_request:
      amount: 700
      amount_details:
        atm_fee: null
        cashback_amount: null
      currency: usd
      is_amount_controllable: false
      merchant_amount: 700
      merchant_currency: usd
      network_risk_score: null
    request_history: []
    status: pending
    transactions: []
    verification_data:
      address_line1_check: not_provided
      address_postal_code_check: match
      cvc_check: match
      expiry_check: match
      authentication_exemption:
        claimed_by: issuer
        type: low_value_transaction
      postal_code: null
      three_d_secure:
        result: required
    wallet: null
    fleet:
      cardholder_prompt_data:
        alphanumeric_id: null
        driver_id: null
        odometer: null
        unspecified_id: null
        user_id: null
        vehicle_number: null
      purchase_type: null
      reported_breakdown:
        fuel:
          gross_amount_decimal: null
        non_fuel:
          gross_amount_decimal: null
        tax:
          local_amount_decimal: null
          national_amount_decimal: null
      service_type: null
    fuel:
      industry_product_code: null
      quantity_decimal: null
      type: null
      unit: null
      unit_cost_decimal: null
    verified_by_fraud_challenge: null
  issuing.card:
    brand: Visa
    cancellation_reason: null
    cardholder:
      billing:
        address:
          city: Beverly Hills
          country: US
          line1: 123 Fake St
          line2: Apt 3
          postal_code: '90210'
          state: CA
      company:
        tax_id_provided: true
      created: 1676675570
      email: jenny@example.com
      id: ich_1Mcd6kJITzLVzkSmsPNd4Aor
      individual:
        dob:
          day: null
          month: null
          year: null
        first_name: null
        last_name: null
        verification:
          document:
            back: null
            front: null
      livemode: false
      metadata: {}
      name: Jenny Rosen
      object: issuing.cardholder
      phone_number: '+18008675309'
      requirements:
        disabled_reason: null
        past_due: []
      spending_controls:
        allowed_categories: []
        blocked_categories: []
        spending_limits: []
        spending_limits_currency: null
        allowed_merchant_countries: null
        blocked_merchant_countries: null
      status: active
      type: individual
      preferred_locales: null
    created: 1234567890
    currency: usd
    exp_month: 8
    exp_year: 2030
    id: ic_1MlLiGJITzLVzkSm501c5IUl
    last4: '4242'
    livemode: false
    metadata: {}
    object: issuing.card
    replaced_by: null
    replacement_for: null
    replacement_reason: null
    shipping:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      address_validation:
        mode: normalization_only
        normalized_address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        result: null
      carrier: null
      customs:
        eori_number: null
      eta: null
      name: name
      phone_number: null
      require_signature: null
      service: express
      status: null
      tracking_number: null
      tracking_url: null
      type: bulk
    spending_controls:
      allowed_categories: null
      blocked_categories: null
      spending_limits: []
      spending_limits_currency: null
      allowed_merchant_countries: null
      blocked_merchant_countries: null
    status: active
    type: physical
    wallets:
      apple_pay:
        eligible: true
        ineligible_reason: null
      google_pay:
        eligible: true
        ineligible_reason: null
      primary_account_identifier: null
    personalization_design: null
    second_line: null
    latest_fraud_warning:
      started_at: null
      type: null
  issuing.cardholder:
    billing:
      address:
        city: Beverly Hills
        country: US
        line1: 123 Fake St
        line2: Apt 3
        postal_code: '90210'
        state: CA
    company:
      tax_id_provided: true
    created: 1234567890
    email: jenny@example.com
    id: ich_1Mcd6kJITzLVzkSmsPNd4Aor
    individual:
      dob:
        day: null
        month: null
        year: null
      first_name: null
      last_name: null
      verification:
        document:
          back: null
          front: null
    livemode: false
    metadata: {}
    name: Jenny Rosen
    object: issuing.cardholder
    phone_number: '+18008675309'
    requirements:
      disabled_reason: null
      past_due: []
    spending_controls:
      allowed_categories: []
      blocked_categories: []
      spending_limits: []
      spending_limits_currency: null
      allowed_merchant_countries: null
      blocked_merchant_countries: null
    status: active
    type: individual
    preferred_locales: null
  issuing.dispute:
    amount: 100
    created: 1234567890
    currency: usd
    evidence:
      fraudulent:
        additional_documentation: null
        explanation: Fraud; card reported lost on 03/14/2023
      reason: fraudulent
    id: idp_1MlLiGJITzLVzkSmOI6HSEx8
    livemode: false
    metadata: {}
    object: issuing.dispute
    status: unsubmitted
    transaction: ipi_1MlLiGJITzLVzkSmMG2YBUPd
  issuing.settlement:
    bin: '424242'
    clearing_date: 1678753656
    created: 1234567890
    currency: usd
    id: ise_1MlLiGJITzLVzkSmPHGJsQ1Q
    interchange_fees: 44
    livemode: false
    metadata: {}
    net_total: 3575
    network: visa
    network_fees: 37
    network_settlement_identifier: '1000633976'
    object: issuing.settlement
    settlement_service: international
    transaction_count: 2
    transaction_volume: 3656
    interchange_fees_amount: 954995977
    net_total_amount: 1180960021
    network_fees_amount: 1785987431
    status: complete
    transaction_amount: 979491623
  issuing.transaction:
    amount: -100
    amount_details:
      atm_fee: null
      cashback_amount: null
    authorization: iauth_1MlLiGJITzLVzkSmL75LlYZd
    balance_transaction: null
    card: ic_1MlLiGJITzLVzkSmKEB9L4Rr
    cardholder: ich_1Mcd6kJITzLVzkSmsPNd4Aor
    created: 1234567890
    currency: usd
    dispute: null
    id: ipi_1MlLiGJITzLVzkSm4D4lbwNj
    livemode: false
    merchant_amount: -100
    merchant_currency: usd
    merchant_data:
      category: taxicabs_limousines
      category_code: '4121'
      city: San Francisco
      country: US
      name: Rocket Rides
      network_id: '1234567890'
      postal_code: '94107'
      state: CA
      tax_id: null
      terminal_id: null
      url: null
    metadata: {}
    object: issuing.transaction
    type: capture
    wallet: apple_pay
    network_data:
      authorization_code: null
      processing_date: null
      transaction_id: null
  item:
    amount_discount: 0
    amount_subtotal: 0
    amount_tax: 0
    amount_total: 0
    currency: usd
    description: T-shirt
    id: li_1MlLiAJITzLVzkSmzUBld3x2
    object: item
    price:
      active: true
      billing_scheme: per_unit
      created: 1676675558
      currency: usd
      custom_unit_amount:
        maximum: null
        minimum: null
        preset: null
      id: price_1Mcd6YJITzLVzkSmJJsJfga5
      livemode: false
      lookup_key: null
      metadata: {}
      nickname: null
      object: price
      product: prod_NNNsbcqAqCJrj2
      recurring:
        interval: month
        interval_count: 797691627
        meter: null
        trial_period_days: null
        usage_type: licensed
      tax_behavior: unspecified
      tiers_mode: null
      transform_quantity:
        divide_by: 1592560163
        round: down
      type: one_time
      unit_amount: 1000
      unit_amount_decimal: '1000'
    quantity: 1
  line_item:
    amount: 1000
    currency: usd
    description: My First Invoice Item (created for API docs)
    discount_amounts: []
    discountable: true
    discounts: []
    id: il_tmp_1MlLi6JITzLVzkSmDouPGUDT
    livemode: false
    metadata: {}
    object: line_item
    period:
      end: 1678753646
      start: 1678753646
    quantity: 1
    subscription: null
    invoice: null
    parent:
      invoice_item_details:
        invoice_item: invoice_item
        proration: true
        proration_details:
          credited_items:
            invoice: invoice
            invoice_line_items:
              - invoice_line_items
        subscription: null
      subscription_item_details:
        invoice_item: null
        proration: true
        proration_details:
          credited_items:
            invoice: invoice
            invoice_line_items:
              - invoice_line_items
        subscription: null
        subscription_item: subscription_item
      type: invoice_item_details
    pretax_credit_amounts: null
    pricing:
      type: price_details
      unit_amount_decimal: null
    taxes: null
  login_link:
    created: 1234567890
    object: login_link
    url: 'https://rwashburne-manage-mydev.dev.stripe.me/express/ZiLE8RvPEZop'
  mandate:
    customer_acceptance:
      accepted_at: 123456789
      online:
        ip_address: 127.0.0.0
        user_agent: device
      type: online
    id: mandate_1MlLiFJITzLVzkSm2nP1Re56
    livemode: false
    multi_use: {}
    object: mandate
    payment_method: pm_123456789
    payment_method_details:
      sepa_debit:
        reference: '123456789'
        url: ''
      type: sepa_debit
    status: active
    type: multi_use
  payment_intent:
    amount: 1099
    amount_capturable: 0
    amount_details:
      tip: {}
    amount_received: 0
    application: null
    application_fee_amount: null
    automatic_payment_methods:
      enabled: true
    canceled_at: 1234567890
    cancellation_reason: null
    capture_method: automatic
    client_secret: pi_1Mcd6XJITzLVzkSmwOxqskee_secret_JwlrslN96B4lvG68fs4kDmrmy
    confirmation_method: automatic
    created: 1234567890
    currency: usd
    customer: null
    description: null
    id: pi_1Mcd6XJITzLVzkSmwOxqskee
    last_payment_error:
      type: idempotency_error
    latest_charge: null
    livemode: false
    metadata: {}
    next_action:
      type: type
    object: payment_intent
    on_behalf_of: null
    payment_method: null
    payment_method_options: {}
    payment_method_types:
      - card
    processing:
      type: card
    receipt_email: null
    review: null
    setup_future_usage: null
    shipping: {}
    statement_descriptor: null
    statement_descriptor_suffix: null
    status: requires_payment_method
    transfer_data:
      destination:
        id: obj_123
        object: account
    transfer_group: null
    payment_method_configuration_details:
      id: obj_123
      parent: null
    source: null
    excluded_payment_method_types: null
  payment_link:
    active: true
    after_completion:
      hosted_confirmation:
        custom_message: null
      type: hosted_confirmation
    allow_promotion_codes: false
    application_fee_amount: null
    application_fee_percent: null
    automatic_tax:
      enabled: false
      liability:
        type: account
    billing_address_collection: auto
    consent_collection:
      payment_method_reuse_agreement:
        position: hidden
      promotions: null
      terms_of_service: null
    currency: usd
    custom_fields: []
    custom_text:
      shipping_address:
        message: message
      submit:
        message: message
      after_submit:
        message: message
      terms_of_service_acceptance:
        message: message
    customer_creation: always
    id: plink_1MlLiGJITzLVzkSmYEeQa9ac
    invoice_creation:
      enabled: true
      invoice_data:
        account_tax_ids: null
        custom_fields: null
        description: null
        footer: null
        issuer:
          type: account
        metadata: null
        rendering_options:
          amount_tax_display: null
          template: null
    livemode: false
    metadata: {}
    object: payment_link
    on_behalf_of: null
    payment_intent_data:
      capture_method: null
      description: null
      metadata:
        undefined: metadata
      setup_future_usage: null
      statement_descriptor: null
      statement_descriptor_suffix: null
      transfer_group: null
    payment_method_collection: always
    payment_method_types: null
    phone_number_collection:
      enabled: false
    shipping_address_collection:
      allowed_countries:
        - SC
    shipping_options: []
    submit_type: auto
    subscription_data:
      description: null
      invoice_settings:
        issuer:
          type: account
      metadata:
        undefined: metadata
      trial_period_days: null
      trial_settings:
        end_behavior:
          missing_payment_method: cancel
    tax_id_collection:
      enabled: false
      required: never
    transfer_data:
      amount: null
      destination:
        id: obj_123
        object: account
    url: >-
      https://rwashburne-payment_links_ingress-mydev.dev.stripe.me/test_14k9DmarJ5q07Nm7ss
    application: null
    inactive_message: null
    restrictions:
      completed_sessions:
        count: 94851343
        limit: 102976443
  payment_method:
    billing_details:
      address:
        city: San Francisco
        country: US
        line1: 1234 Fake Street
        line2: null
        postal_code: '94102'
        state: CA
      email: jenny@example.com
      name: null
      phone: '+15555555555'
      tax_id: null
    card:
      brand: visa
      checks:
        address_line1_check: null
        address_postal_code_check: null
        cvc_check: pass
      country: US
      exp_month: 8
      exp_year: 2030
      fingerprint: XFO13q66ulrWf0ou
      funding: credit
      generated_from:
        charge: null
        payment_method_details:
          type: type
        setup_attempt: null
      last4: '4242'
      networks:
        available:
          - visa
        preferred: null
      three_d_secure_usage:
        supported: true
      wallet:
        dynamic_last4: null
        type: link
      display_brand: null
      regulated_status: null
    created: 1234567890
    customer: null
    id: pm_1MlLi5JITzLVzkSmZEk8HwXY
    livemode: false
    metadata:
      order_id: '123456789'
    object: payment_method
    type: card
  payment_source:
    business_profile:
      mcc: null
      name: null
      product_description: null
      support_address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      support_email: null
      support_phone: null
      support_url: null
      url: null
      minority_owned_business_designation: null
    business_type: null
    capabilities:
      card_payments: active
      transfers: active
    charges_enabled: false
    controller:
      type: account
    country: US
    created: 1675277004
    default_currency: usd
    details_submitted: false
    email: site@stripe.com
    external_accounts:
      data: []
      has_more: false
      object: list
      url: /v1/accounts/acct_1MWlHDJITzLVzkSm/external_accounts
    future_requirements:
      alternatives: []
      current_deadline: null
      currently_due: []
      disabled_reason: null
      errors: []
      eventually_due: []
      past_due: []
      pending_verification: []
    id: acct_1MWlHDJITzLVzkSm
    metadata: {}
    object: account
    payouts_enabled: false
    requirements:
      alternatives: []
      current_deadline: null
      currently_due:
        - business_profile.product_description
        - business_profile.support_phone
        - business_profile.url
        - external_account
        - tos_acceptance.date
        - tos_acceptance.ip
      disabled_reason: requirements.past_due
      errors: []
      eventually_due:
        - business_profile.product_description
        - business_profile.support_phone
        - business_profile.url
        - external_account
        - tos_acceptance.date
        - tos_acceptance.ip
      past_due: []
      pending_verification: []
    settings:
      bacs_debit_payments:
        display_name: null
        service_user_number: null
      branding:
        icon: null
        logo: null
        primary_color: null
        secondary_color: null
      card_issuing:
        tos_acceptance:
          date: null
          ip: null
      card_payments:
        decline_on:
          avs_failure: true
          cvc_failure: true
        statement_descriptor_prefix: null
        statement_descriptor_prefix_kana: null
        statement_descriptor_prefix_kanji: null
      dashboard:
        display_name: null
        timezone: Etc/UTC
      payments:
        statement_descriptor: null
        statement_descriptor_kana: null
        statement_descriptor_kanji: null
        statement_descriptor_prefix_kana: null
        statement_descriptor_prefix_kanji: null
      payouts:
        debit_negative_balances: true
        schedule:
          delay_days: 2
          interval: daily
        statement_descriptor: null
      sepa_debit_payments: {}
    tos_acceptance:
      date: null
      ip: null
      user_agent: null
    type: standard
  payout:
    amount: 1100
    arrival_date: 1234567890
    automatic: true
    balance_transaction: txn_1MlLhiJITzLVzkSm0tDIM70A
    created: 1234567890
    currency: usd
    description: STRIPE PAYOUT
    destination: ba_1MlLiCJITzLVzkSmzTHBeJt2
    failure_balance_transaction: null
    failure_code: null
    failure_message: null
    id: po_1MlLiCJITzLVzkSmTO8DFctc
    livemode: false
    metadata: {}
    method: standard
    object: payout
    original_payout: null
    reconciliation_status: not_applicable
    reversed_by: null
    source_type: card
    statement_descriptor: null
    status: in_transit
    type: bank_account
    application_fee: null
    application_fee_amount: null
    trace_id:
      status: status
      value: null
    payout_method: null
  person:
    account: acct_1MWlHDJITzLVzkSm
    created: 1234567890
    dob:
      day: null
      month: null
      year: null
    first_name: null
    future_requirements:
      alternatives: []
      currently_due: []
      errors: []
      eventually_due: []
      past_due: []
      pending_verification: []
    id: person_1MlLiHJITzLVzkSmB4pg1uK9
    id_number_provided: false
    last_name: null
    metadata: {}
    object: person
    relationship:
      director: false
      executive: false
      owner: false
      percent_ownership: null
      representative: false
      title: null
      authorizer: null
      legal_guardian: null
    requirements:
      alternatives: []
      currently_due: []
      errors: []
      eventually_due: []
      past_due: []
      pending_verification: []
    ssn_last_4_provided: false
    verification:
      additional_document:
        back: null
        details: null
        details_code: null
        front: null
      details: null
      details_code: null
      document:
        back: null
        details: null
        details_code: null
        front: null
      status: unverified
  plan:
    active: true
    amount: 2000
    amount_decimal: '2000'
    billing_scheme: per_unit
    created: 1234567890
    currency: usd
    id: price_1Mcd6ZJITzLVzkSmwd29pdd3
    interval: month
    interval_count: 1
    livemode: false
    metadata: {}
    nickname: null
    object: plan
    product: prod_NNNsbcqAqCJrj2
    tiers_mode: null
    transform_usage:
      divide_by: 1592560163
      round: down
    trial_period_days: null
    usage_type: licensed
    meter: null
  price:
    active: true
    billing_scheme: per_unit
    created: 1234567890
    currency: usd
    custom_unit_amount:
      maximum: null
      minimum: null
      preset: null
    id: price_1Mcd6ZJITzLVzkSmwd29pdd3
    livemode: false
    lookup_key: null
    metadata: {}
    nickname: null
    object: price
    product: prod_NNNsbcqAqCJrj2
    recurring:
      interval: month
      interval_count: 1
      usage_type: licensed
      meter: null
      trial_period_days: null
    tax_behavior: unspecified
    tiers_mode: null
    transform_quantity:
      divide_by: 1592560163
      round: down
    type: recurring
    unit_amount: 2000
    unit_amount_decimal: '2000'
  product:
    active: true
    created: 1234567890
    default_price: price_1Mcd6YJITzLVzkSmsV8lHm33
    description: Comfortable gray cotton t-shirt
    id: prod_NNNsbcqAqCJrj2
    images: []
    livemode: false
    metadata: {}
    name: T-shirt
    object: product
    package_dimensions:
      height: 1221029593
      length: 1106363674
      weight: 791592328
      width: 113126854
    shippable: null
    statement_descriptor: null
    tax_code: null
    unit_label: null
    updated: 1234567890
    url: null
    marketing_features:
      - {}
    type: good
  promotion_code:
    active: false
    code: FALL20
    created: 1234567890
    customer: null
    expires_at: 1234567890
    id: promo_1MlLiAJITzLVzkSmAKV6tZ50
    livemode: false
    max_redemptions: null
    metadata: {}
    object: promotion_code
    restrictions:
      first_time_transaction: false
      minimum_amount: null
      minimum_amount_currency: null
    times_redeemed: 0
    promotion:
      coupon: null
      type: coupon
  quote:
    amount_subtotal: 0
    amount_total: 0
    application: null
    application_fee_amount: null
    application_fee_percent: null
    automatic_tax:
      enabled: false
      status: null
      liability:
        type: account
      provider: null
    collection_method: charge_automatically
    computed:
      recurring:
        amount_subtotal: 1555417355
        amount_total: 1117121693
        interval: month
        interval_count: 797691627
        total_details:
          amount_discount: 406046392
          amount_shipping: null
          amount_tax: 1424534716
      upfront:
        amount_subtotal: 0
        amount_total: 0
        total_details:
          amount_discount: 0
          amount_shipping: 0
          amount_tax: 0
    created: 1234567890
    currency: usd
    customer: cus_NNNslJKODLsLoG
    default_tax_rates: []
    description: null
    discounts: []
    expires_at: 1234567890
    footer: null
    from_quote:
      is_revision: true
      quote: quote
    header: null
    id: qt_1MlLiAJITzLVzkSmgwkSkaNM
    invoice: null
    invoice_settings:
      days_until_due: null
      issuer:
        type: account
    livemode: false
    metadata: {}
    number: null
    object: quote
    on_behalf_of: null
    status: draft
    status_transitions:
      accepted_at: null
      canceled_at: null
      finalized_at: null
    subscription: null
    subscription_data:
      description: null
      effective_date: null
      trial_period_days: null
      metadata: null
      billing_mode:
        type: classic
    subscription_schedule: null
    test_clock: null
    total_details:
      amount_discount: 0
      amount_shipping: 0
      amount_tax: 0
    transfer_data:
      amount: null
      amount_percent: null
      destination:
        id: obj_123
        object: account
  radar.early_fraud_warning:
    actionable: true
    charge: ch_1234
    created: 1234567890
    fraud_type: misc
    id: issfr_1MlLiHJITzLVzkSmoMY1CPmo
    livemode: false
    object: radar.early_fraud_warning
  radar.value_list:
    alias: custom_ip_blocklist
    created: 1234567890
    created_by: jenny@example.com
    id: rsl_1MlLiGJITzLVzkSmi6kJ5coN
    item_type: ip_address
    list_items:
      data: []
      has_more: false
      object: list
      url: /v1/radar/value_list_items?value_list=rsl_1MlLiGJITzLVzkSmi6kJ5coN
    livemode: false
    metadata: {}
    name: Custom IP Blocklist
    object: radar.value_list
  radar.value_list_item:
    created: 1234567890
    created_by: jenny@example.com
    id: rsli_1MlLiGJITzLVzkSmBdrq4Qmw
    livemode: false
    object: radar.value_list_item
    value: 1.2.3.4
    value_list: rsl_1MlLiGJITzLVzkSmBlAoqGLm
  refund:
    amount: 100
    balance_transaction: null
    charge: ch_1Mcd6UJITzLVzkSmp1XIBHoW
    created: 1234567890
    currency: usd
    id: re_1MlLi1JITzLVzkSmYjN8VXsL
    metadata: {}
    object: refund
    payment_intent: null
    reason: null
    receipt_number: null
    source_transfer_reversal: null
    status: succeeded
    transfer_reversal: null
  reporting.report_run:
    created: 1234567890
    error: null
    id: frr_1MlLiHJITzLVzkSm0Praf3Po
    livemode: true
    object: reporting.report_run
    parameters:
      interval_end: 1525132800
      interval_start: 1522540800
    report_type: balance.summary.1
    result:
      created: 1676675571
      expires_at: 1708211571
      filename: file_1Mcd6lJITzLVzkSm58IV6lDd
      id: file_1Mcd6lJITzLVzkSm58IV6lDd
      links:
        data: []
        has_more: false
        object: list
        url: /v1/file_links?file=file_1Mcd6lJITzLVzkSm58IV6lDd
      object: file
      purpose: finance_report_run
      size: 16890
      title: null
      type: csv
      url: >-
        https://rwashburne-upload-mydev.dev.stripe.me/v1/files/file_1Mcd6lJITzLVzkSm58IV6lDd/contents
    status: succeeded
    succeeded_at: 1234567890
  reporting.report_type:
    data_available_end: 1234567890
    data_available_start: 1234567890
    default_columns:
      - category
      - currency
      - description
      - net_amount
    id: balance.summary.1
    livemode: true
    name: Balance summary
    object: reporting.report_type
    updated: 1234567890
    version: 1
  review:
    billing_zip: null
    charge: ch_1Mcd6UJITzLVzkSmp1XIBHoW
    created: 1234567890
    id: prv_1MlLiHJITzLVzkSmWOL5pISl
    ip_address: null
    ip_address_location:
      city: null
      country: null
      latitude: null
      longitude: null
      region: null
    livemode: false
    object: review
    open: true
    opened_reason: rule
    session:
      browser: null
      device: null
      platform: null
      version: null
    closed_reason: null
    reason: reason
  scheduled_query_run:
    created: 1234567890
    data_load_time: 1234567890
    file:
      created: 1676675571
      expires_at: null
      filename: path
      id: file_1Mcd6lJITzLVzkSm8nY5Nuq6
      links:
        data: []
        has_more: false
        object: list
        url: /v1/file_links?file=file_1Mcd6lJITzLVzkSm8nY5Nuq6
      object: file
      purpose: sigma_scheduled_query
      size: 500
      title: null
      type: csv
      url: >-
        https://rwashburne-upload-mydev.dev.stripe.me/v1/files/file_1Mcd6lJITzLVzkSm8nY5Nuq6/contents
    id: sqr_1MlLiHJITzLVzkSmVs2VPecm
    livemode: false
    object: scheduled_query_run
    result_available_until: 1234567890
    sql: SELECT count(*) from charges
    status: completed
    title: Count all charges
  setup_attempt:
    application: null
    created: 1234567890
    customer: null
    flow_directions: null
    id: setatt_123456789012345678901234
    livemode: false
    object: setup_attempt
    on_behalf_of: null
    payment_method: card_1Mcd6SJITzLVzkSmqkE2eJHO
    payment_method_details:
      card:
        three_d_secure:
          authentication_flow: null
          electronic_commerce_indicator: null
          result: null
          result_reason: null
          transaction_id: null
          version: null
        brand: null
        checks:
          address_line1_check: null
          address_postal_code_check: null
          cvc_check: null
        country: null
        exp_month: null
        exp_year: null
        funding: null
        last4: null
        network: null
        wallet:
          type: apple_pay
      type: card
    setup_error:
      type: idempotency_error
    setup_intent: seti_1Mcd6kJITzLVzkSmqX6ZT84q
    status: succeeded
    usage: off_session
  setup_intent:
    application: null
    cancellation_reason: null
    client_secret: seti_1Mcd6kJITzLVzkSmqX6ZT84q_secret_NNNsR9WdNTeUghIWEQ17mHkxAFqeEke
    created: 1234567890
    customer: null
    description: null
    flow_directions: null
    id: seti_1Mcd6kJITzLVzkSmqX6ZT84q
    last_setup_error:
      type: idempotency_error
    latest_attempt: null
    livemode: false
    mandate: null
    metadata: {}
    next_action:
      type: type
    object: setup_intent
    on_behalf_of: null
    payment_method: null
    payment_method_options: {}
    payment_method_types:
      - card
    single_use_mandate: null
    status: requires_payment_method
    usage: off_session
    automatic_payment_methods:
      enabled: null
    payment_method_configuration_details:
      id: obj_123
      parent: null
    excluded_payment_method_types: null
  shipping_rate:
    active: true
    created: 1234567890
    delivery_estimate:
      maximum:
        unit: month
        value: 111972721
      minimum:
        unit: month
        value: 111972721
    display_name: Ground shipping
    fixed_amount:
      amount: 500
      currency: usd
    id: shr_1MlLiGJITzLVzkSmXX5RcAAI
    livemode: false
    metadata: {}
    object: shipping_rate
    tax_behavior: unspecified
    tax_code: null
    type: fixed_amount
  source:
    ach_credit_transfer:
      account_number: test_52796e3294dc
      bank_name: TEST BANK
      fingerprint: ecpwEzmBOSMOqQTL
      routing_number: '110000000'
      swift_code: TSTEZ122
    amount: null
    client_secret: src_client_secret_wYQdFOogqwPJBBlUrHljPe8E
    created: 1234567890
    currency: usd
    flow: receiver
    id: src_1MlLiAJITzLVzkSm3n0rctNQ
    livemode: false
    metadata: {}
    object: source
    owner:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      email: jenny.rosen@example.com
      name: null
      phone: null
      verified_address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      verified_email: null
      verified_name: null
      verified_phone: null
    receiver:
      address: 121042882-38381234567890123
      amount_charged: 0
      amount_received: 0
      amount_returned: 0
      refund_attributes_method: email
      refund_attributes_status: missing
    statement_descriptor: null
    status: pending
    type: ach_credit_transfer
    usage: reusable
    allow_redisplay: null
  source_mandate_notification:
    amount: 2000
    created: 1234567890
    id: srcmn_1MlLiFJITzLVzkSmoH4V7ORh
    livemode: false
    object: source_mandate_notification
    reason: debit_initiated
    sepa_debit:
      creditor_identifier: TEST42ZZZ0000424242
      last4: '3000'
      mandate_reference: FFU45BAKH9LWLMM0
    source:
      ach_credit_transfer:
        account_number: test_52796e3294dc
        bank_name: TEST BANK
        fingerprint: ecpwEzmBOSMOqQTL
        routing_number: '110000000'
        swift_code: TSTEZ122
      amount: null
      client_secret: src_client_secret_CZxrS1NoKHckpwNE0qeS5cNM
      created: 1678753655
      currency: usd
      flow: receiver
      id: src_1MlLiFJITzLVzkSmKqKS5h82
      livemode: false
      metadata: {}
      object: source
      owner:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: jenny.rosen@example.com
        name: null
        phone: null
        verified_address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        verified_email: null
        verified_name: null
        verified_phone: null
      receiver:
        address: 121042882-38381234567890123
        amount_charged: 0
        amount_received: 0
        amount_returned: 0
        refund_attributes_method: email
        refund_attributes_status: missing
      statement_descriptor: null
      status: pending
      type: ach_credit_transfer
      usage: reusable
      allow_redisplay: null
    status: submitted
    type: sepa_debit
  source_transaction:
    ach_credit_transfer: {}
    amount: 500
    created: 1234567890
    currency: usd
    id: srctxn_1MlLiFJITzLVzkSm2a0LNUxZ
    livemode: false
    object: source_transaction
    source: src_1MlLiAJITzLVzkSm3n0rctNQ
    status: succeeded
    type: ach_credit_transfer
  subscription:
    application: null
    application_fee_percent: null
    automatic_tax:
      enabled: false
      disabled_reason: null
      liability:
        type: account
    billing_cycle_anchor: 1234567890
    billing_thresholds:
      amount_gte: null
      reset_billing_cycle_anchor: null
    cancel_at: 1234567890
    cancel_at_period_end: false
    canceled_at: 1234567890
    cancellation_details:
      comment: null
      feedback: null
      reason: null
    collection_method: charge_automatically
    created: 1234567890
    currency: usd
    customer: cus_NNNslJKODLsLoG
    days_until_due: null
    default_payment_method: null
    default_source: null
    default_tax_rates: []
    description: null
    ended_at: 1234567890
    id: sub_1MlLi1JITzLVzkSmbGPN6d9R
    items:
      data:
        - billing_thresholds:
            usage_gte: null
          created: 1678753641
          id: si_NWOVO8ZMEsRVpj
          metadata: {}
          object: subscription_item
          price:
            active: true
            billing_scheme: per_unit
            created: 1676675559
            currency: usd
            custom_unit_amount:
              maximum: null
              minimum: null
              preset: null
            id: price_1Mcd6ZJITzLVzkSmwd29pdd3
            livemode: false
            lookup_key: null
            metadata: {}
            nickname: null
            object: price
            product: prod_NNNsbcqAqCJrj2
            recurring:
              interval: month
              interval_count: 1
              usage_type: licensed
              meter: null
              trial_period_days: null
            tax_behavior: unspecified
            tiers_mode: null
            transform_quantity:
              divide_by: 1592560163
              round: down
            type: recurring
            unit_amount: 2000
            unit_amount_decimal: '2000'
          quantity: 1
          subscription: sub_1MlLi1JITzLVzkSmbGPN6d9R
          tax_rates: []
          current_period_end: 976287773
          current_period_start: 1896570518
          discounts:
            - checkout_session: null
              customer: null
              end: null
              id: obj_123
              invoice: null
              invoice_item: null
              object: discount
              promotion_code: null
              start: 109757538
              subscription: null
              subscription_item: null
              source:
                coupon: null
                type: coupon
          plan:
            active: true
            amount: null
            amount_decimal: null
            billing_scheme: tiered
            created: 1028554472
            currency: currency
            id: obj_123
            interval: month
            interval_count: 797691627
            livemode: true
            metadata: null
            meter: null
            nickname: null
            object: plan
            product: null
            tiers_mode: null
            transform_usage:
              divide_by: 1592560163
              round: down
            trial_period_days: null
            usage_type: licensed
          billed_until: null
      has_more: false
      object: list
      url: /v1/subscription_items?subscription=sub_1MlLi1JITzLVzkSmbGPN6d9R
    latest_invoice: null
    livemode: false
    metadata: {}
    next_pending_invoice_item_invoice: 1234567890
    object: subscription
    on_behalf_of: null
    pause_collection:
      behavior: mark_uncollectible
      resumes_at: null
    payment_settings:
      payment_method_options:
        acss_debit: {}
        bancontact:
          preferred_language: fr
        card:
          network: null
          request_three_d_secure: null
        customer_balance:
          funding_type: null
        konbini: {}
        sepa_debit: {}
        us_bank_account: {}
      payment_method_types: null
      save_default_payment_method: null
    pending_invoice_item_interval:
      interval: month
      interval_count: 797691627
    pending_setup_intent: null
    pending_update:
      billing_cycle_anchor: null
      expires_at: 833811170
      subscription_items: null
      trial_end: null
      trial_from_plan: null
    schedule: null
    start_date: 1234567890
    status: active
    test_clock: null
    transfer_data:
      amount_percent: null
      destination:
        id: obj_123
        object: account
    trial_end: 1234567890
    trial_settings:
      end_behavior:
        missing_payment_method: create_invoice
    trial_start: 1234567890
    billing_cycle_anchor_config:
      day_of_month: 1361669285
      hour: null
      minute: null
      month: null
      second: null
    discounts:
      - checkout_session: null
        customer: null
        end: null
        id: obj_123
        invoice: null
        invoice_item: null
        object: discount
        promotion_code: null
        start: 109757538
        subscription: null
        subscription_item: null
        source:
          coupon: null
          type: coupon
    invoice_settings:
      account_tax_ids: null
      issuer:
        type: account
    billing_mode:
      type: classic
      flexible: {}
  subscription_item:
    billing_thresholds:
      usage_gte: null
    created: 1678753647
    id: si_NWOVMvXVc2SbwK
    metadata: {}
    object: subscription_item
    price:
      active: true
      billing_scheme: per_unit
      created: 1676675559
      currency: usd
      custom_unit_amount:
        maximum: null
        minimum: null
        preset: null
      id: price_1Mcd6ZJITzLVzkSmwd29pdd3
      livemode: false
      lookup_key: null
      metadata: {}
      nickname: null
      object: price
      product: prod_NNNsbcqAqCJrj2
      recurring:
        interval: month
        interval_count: 1
        usage_type: licensed
        meter: null
        trial_period_days: null
      tax_behavior: unspecified
      tiers_mode: null
      transform_quantity:
        divide_by: 1592560163
        round: down
      type: recurring
      unit_amount: 2000
      unit_amount_decimal: '2000'
    quantity: 1
    subscription: sub_1MlLi6JITzLVzkSmHTXG5qr4
    tax_rates: []
    current_period_end: 976287773
    current_period_start: 1896570518
    discounts:
      - checkout_session: null
        customer: null
        end: null
        id: obj_123
        invoice: null
        invoice_item: null
        object: discount
        promotion_code: null
        start: 109757538
        subscription: null
        subscription_item: null
        source:
          coupon: null
          type: coupon
    plan:
      active: true
      amount: null
      amount_decimal: null
      billing_scheme: tiered
      created: 1028554472
      currency: currency
      id: obj_123
      interval: month
      interval_count: 797691627
      livemode: true
      metadata: null
      meter: null
      nickname: null
      object: plan
      product: null
      tiers_mode: null
      transform_usage:
        divide_by: 1592560163
        round: down
      trial_period_days: null
      usage_type: licensed
    billed_until: null
  subscription_schedule:
    application: null
    canceled_at: 1234567890
    completed_at: 1234567890
    created: 1234567890
    current_phase:
      end_date: 1725067410
      start_date: 1573629589
    customer: cus_NNNslJKODLsLoG
    default_settings:
      application_fee_percent: null
      automatic_tax:
        enabled: false
        disabled_reason: null
        liability:
          type: account
      billing_cycle_anchor: automatic
      billing_thresholds:
        amount_gte: null
        reset_billing_cycle_anchor: null
      collection_method: charge_automatically
      default_payment_method: null
      description: null
      invoice_settings:
        account_tax_ids: null
        days_until_due: null
        issuer:
          type: account
      on_behalf_of: null
      transfer_data:
        amount_percent: null
        destination:
          id: obj_123
          object: account
    end_behavior: release
    id: sub_sched_1MlLi6JITzLVzkSmq8cd43lM
    livemode: false
    metadata: {}
    object: subscription_schedule
    phases:
      - add_invoice_items: []
        application_fee_percent: null
        billing_cycle_anchor: null
        billing_thresholds:
          amount_gte: null
          reset_billing_cycle_anchor: null
        collection_method: null
        currency: usd
        default_payment_method: null
        default_tax_rates: []
        description: null
        end_date: 1710808046
        invoice_settings:
          account_tax_ids: null
          days_until_due: null
          issuer:
            type: account
        items:
          - billing_thresholds:
              usage_gte: null
            metadata: {}
            price: price_1Mcd6ZJITzLVzkSmwd29pdd3
            quantity: 1
            tax_rates: []
            discounts:
              - coupon: null
                discount: null
                promotion_code: null
            plan:
              active: true
              amount: null
              amount_decimal: null
              billing_scheme: tiered
              created: 1028554472
              currency: currency
              id: obj_123
              interval: month
              interval_count: 797691627
              livemode: true
              metadata: null
              meter: null
              nickname: null
              object: plan
              product: null
              tiers_mode: null
              transform_usage:
                divide_by: 1592560163
                round: down
              trial_period_days: null
              usage_type: licensed
        metadata: {}
        on_behalf_of: null
        proration_behavior: create_prorations
        start_date: 1679358446
        transfer_data:
          amount_percent: null
          destination:
            id: obj_123
            object: account
        trial_end: null
        discounts:
          - coupon: null
            discount: null
            promotion_code: null
    released_at: 1234567890
    released_subscription: null
    status: not_started
    subscription: null
    test_clock: null
    billing_mode:
      type: classic
      flexible: {}
  tax_code:
    description: >-
      Any tangible or physical good. For jurisdictions that impose a tax, the
      standard rate is applied.
    id: txcd_99999999
    name: General - Tangible Goods
    object: tax_code
  tax_id:
    country: DE
    created: 1234567890
    customer: cus_NNNslJKODLsLoG
    id: txi_1MlLiHJITzLVzkSmi1opmyET
    livemode: false
    object: tax_id
    type: eu_vat
    value: DE123456789
    verification:
      status: pending
      verified_address: null
      verified_name: null
    owner:
      type: customer
  tax_rate:
    active: true
    country: DE
    created: 1234567890
    description: VAT Germany
    display_name: VAT
    id: txr_1MlLi6JITzLVzkSm1zvAk9SI
    inclusive: false
    jurisdiction: DE
    livemode: false
    metadata: {}
    object: tax_rate
    percentage: 19
    state: null
    tax_type: vat
    effective_percentage: null
    flat_amount:
      amount: 1413853096
      currency: currency
    jurisdiction_level: null
    rate_type: null
  terminal.configuration:
    bbpos_wisepos_e:
      splashscreen: file_1MlLiGJITzLVzkSmR2KjdTh9
    id: tmc_ElVUAjF8xXG3hj
    is_account_default: false
    livemode: false
    object: terminal.configuration
    name: null
  terminal.connection_token:
    object: terminal.connection_token
    secret: pst_test_wfryJuBmDGBbWWHmwF3Btov
  terminal.location:
    address:
      city: San Francisco
      country: US
      line1: 1234 Fake Street
      line2: null
      postal_code: '94102'
      state: CA
    display_name: My First Store
    id: tml_cKQQfm6UGarpNRJRxXpzca4i
    livemode: false
    metadata: {}
    object: terminal.location
  terminal.reader:
    action:
      failure_code: null
      failure_message: null
      status: failed
      type: process_payment_intent
    device_sw_version: null
    device_type: bbpos_wisepos_e
    id: tmr_cKxInTQKOxDTvasletECzYvQ
    ip_address: 192.168.2.2
    label: Blue Rabbit
    livemode: false
    location: null
    metadata: {}
    object: terminal.reader
    serial_number: 123-456-789
    status: online
    last_seen_at: null
  test_helpers.test_clock:
    created: 1234567890
    deletes_after: 1234567890
    frozen_time: 1234567890
    id: clock_1MlLiAJITzLVzkSmVBT841xQ
    livemode: false
    name: null
    object: test_helpers.test_clock
    status: ready
    status_details: {}
  token:
    card:
      address_city: null
      address_country: null
      address_line1: null
      address_line1_check: null
      address_line2: null
      address_state: null
      address_zip: null
      address_zip_check: null
      brand: Visa
      country: US
      cvc_check: pass
      dynamic_last4: null
      exp_month: 8
      exp_year: 2030
      fingerprint: XFO13q66ulrWf0ou
      funding: credit
      id: card_1MlLi6JITzLVzkSmKK0xVnJV
      last4: '4242'
      metadata: {}
      name: null
      object: card
      tokenization_method: null
      regulated_status: null
    client_ip: null
    created: 1234567890
    id: tok_1MlLi6JITzLVzkSmkWbVmpka
    livemode: false
    object: token
    type: card
    used: false
  topup:
    amount: 1000
    balance_transaction: null
    created: 1234567890
    currency: usd
    description: Top-up description
    expected_availability_date: 123456789
    failure_code: null
    failure_message: null
    id: tu_1MlLiCJITzLVzkSm27UsrBQR
    livemode: false
    metadata:
      order_id: '12345678'
    object: topup
    source:
      ach_debit:
        bank_name: STRIPE TEST BANK
        country: US
        fingerprint: 5Wh4KBcfDrz5IOnx
        last4: '6789'
        routing_number: '110000000'
        type: individual
      amount: null
      client_secret: src_client_secret_c49ljuKNc9fQLJauoN4Tx4nv
      created: 1678753652
      currency: usd
      flow: code_verification
      id: src_1MlLiCJITzLVzkSmr35MnAkA
      livemode: false
      metadata: {}
      object: source
      owner:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: jenny.rosen@example.com
        name: Jenny Rosen
        phone: null
        verified_address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        verified_email: null
        verified_name: null
        verified_phone: null
      statement_descriptor: null
      status: pending
      type: ach_debit
      usage: reusable
      allow_redisplay: null
    statement_descriptor: null
    status: pending
    transfer_group: null
  transfer:
    amount: 1100
    amount_reversed: 0
    balance_transaction: txn_1MlLhiJITzLVzkSm0tDIM70A
    created: 1234567890
    currency: usd
    description: null
    destination: acct_1MWlHDJITzLVzkSm
    destination_payment: py_NWOVg9IZfr7zTN
    id: tr_1MlLiCJITzLVzkSmn2LkBD3D
    livemode: false
    metadata: {}
    object: transfer
    reversals:
      data: []
      has_more: false
      object: list
      url: /v1/transfers/tr_1MlLiCJITzLVzkSmn2LkBD3D/reversals
    reversed: false
    source_transaction: null
    source_type: card
    transfer_group: null
  transfer_reversal:
    amount: 1100
    balance_transaction: null
    created: 1234567890
    currency: usd
    destination_payment_refund: null
    id: trr_1MlLiCJITzLVzkSmHjIWDgJC
    metadata: {}
    object: transfer_reversal
    source_refund: null
    transfer: tr_1MlLiCJITzLVzkSmn2LkBD3D
  treasury.credit_reversal:
    amount: 1000
    created: 1234567890
    currency: usd
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPz-vqAGMgbmx6_xLNs6Nv21sYMAkhwf9fKBf4dwaXtcyYHI6RJvoy5ooR4wUlS6ng7vY3RPw4YARBwUrYqvSjsk5dtNmg
    id: credrev_1MlLiKJITzLVzkSmvK3f86lv
    livemode: false
    metadata: {}
    network: ach
    object: treasury.credit_reversal
    received_credit: rc_1MlLiKJITzLVzkSmZ2SULswc
    status: processing
    status_transitions:
      posted_at: null
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
  treasury.debit_reversal:
    amount: 1000
    created: 1234567890
    currency: usd
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPz-vqAGMgZDZ51a_hY6Nv3t9ulTyAOqM3QNvHoYNHX5LLObIyp4NkNyWufKUHd81tN6525dWjN13_QXOzOpG5dt_Zmp0w
    id: debrev_1MlLiKJITzLVzkSm1lT04zxj
    linked_flows:
      issuing_dispute: null
    livemode: false
    metadata: {}
    network: ach
    object: treasury.debit_reversal
    received_debit: rd_1MlLiKJITzLVzkSmFInrmpBp
    status: processing
    status_transitions:
      completed_at: null
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
  treasury.financial_account:
    active_features:
      - financial_addresses.aba
      - outbound_payments.ach
      - outbound_payments.us_domestic_wire
    balance:
      cash:
        usd: 0
      inbound_pending:
        usd: 0
      outbound_pending:
        usd: 0
    country: US
    created: 1234567890
    financial_addresses:
      - aba:
          account_holder_name: Jenny Rosen
          account_number_last4: '7890'
          bank_name: STRIPE TEST BANK
          routing_number: '0000000001'
        supported_networks:
          - ach
          - us_domestic_wire
        type: aba
    id: fa_1MlLiEJITzLVzkSmGTgLnr26
    livemode: true
    metadata: null
    object: treasury.financial_account
    pending_features: []
    restricted_features: []
    status: open
    status_details:
      closed:
        reasons:
          - closed_by_platform
    supported_currencies:
      - usd
  treasury.financial_account_features:
    card_issuing:
      requested: true
      status: active
      status_details: []
    deposit_insurance:
      requested: true
      status: active
      status_details: []
    financial_addresses:
      aba:
        requested: true
        status: active
        status_details: []
    inbound_transfers:
      ach:
        requested: true
        status: active
        status_details: []
    intra_stripe_flows:
      requested: true
      status: active
      status_details: []
    object: treasury.financial_account_features
    outbound_payments:
      ach:
        requested: true
        status: active
        status_details: []
      us_domestic_wire:
        requested: true
        status: active
        status_details: []
    outbound_transfers:
      ach:
        requested: true
        status: active
        status_details: []
      us_domestic_wire:
        requested: true
        status: active
        status_details: []
  treasury.inbound_transfer:
    amount: 10000
    cancelable: true
    created: 1234567890
    currency: usd
    description: InboundTransfer from my external bank account
    failure_details:
      code: insufficient_funds
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPz-vqAGMgbIrT0ncs86Nv1b7-dmn-4hJEGVoI-smtUdPWVGW3Wbb1nBwqZgkSqLMc-elq0lxXdm9u22M9atQXMAkvtiZg
    id: ibt_1MlLiKJITzLVzkSmgCsDC5fT
    linked_flows:
      received_debit: null
    livemode: false
    metadata: {}
    object: treasury.inbound_transfer
    origin_payment_method: pm_1MlLiIJITzLVzkSmLsWswemN
    origin_payment_method_details:
      billing_details:
        address:
          city: San Francisco
          country: US
          line1: 1234 Fake Street
          line2: null
          postal_code: '94102'
          state: CA
        email: null
        name: Jane Austen
      type: us_bank_account
      us_bank_account:
        account_holder_type: company
        account_type: checking
        bank_name: STRIPE TEST BANK
        fingerprint: I1e2zttmxgyFZKaM
        last4: '6789'
        network: ach
        routing_number: '110000000'
    returned: false
    statement_descriptor: transfer
    status: processing
    status_transitions:
      failed_at: null
      succeeded_at: null
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
  treasury.outbound_payment:
    amount: 10000
    cancelable: false
    created: 1234567890
    currency: usd
    customer: null
    description: OutboundPayment to a 3rd party
    destination_payment_method: null
    destination_payment_method_details:
      type: us_bank_account
      billing_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: null
    end_user_details:
      ip_address: null
      present: false
    expected_arrival_date: 1234567890
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPv-vqAGMgYUJeztnyc6Nf30Bpr3LQPgh7WU2-eGiAEd9CYMPSVvIOsNUzlditRHhezcfqb2fdnmrvCWfLirtbhpDrKK
    id: obp_1MlLiJJITzLVzkSmZhwYuWfP
    livemode: false
    metadata: {}
    object: treasury.outbound_payment
    returned_details:
      code: account_frozen
      transaction:
        amount: 1413853096
        balance_impact:
          cash: 3046195
          inbound_pending: 550878511
          outbound_pending: 786770760
        created: 1028554472
        currency: currency
        description: description
        financial_account: financial_account
        flow: null
        flow_type: credit_reversal
        id: obj_123
        livemode: true
        object: treasury.transaction
        status: open
        status_transitions:
          posted_at: null
          void_at: null
    statement_descriptor: payment
    status: processing
    status_transitions:
      canceled_at: null
      failed_at: null
      posted_at: null
      returned_at: null
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
    tracking_details:
      type: ach
  treasury.outbound_transfer:
    amount: 10000
    cancelable: true
    created: 1234567890
    currency: usd
    description: OutboundTransfer to my external bank account
    destination_payment_method: pm_1MlLiIJITzLVzkSmLsWswemN
    destination_payment_method_details:
      billing_details:
        address:
          city: San Francisco
          country: US
          line1: 1234 Fake Street
          line2: null
          postal_code: '94102'
          state: CA
        email: null
        name: Jane Austen
      type: us_bank_account
      us_bank_account:
        account_holder_type: company
        account_type: checking
        bank_name: STRIPE TEST BANK
        fingerprint: I1e2zttmxgyFZKaM
        last4: '6789'
        network: ach
        routing_number: '110000000'
    expected_arrival_date: 1234567890
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPv-vqAGMgYDmHJoSRs6Nv2uwQRyji7_9RKpVOoWCULfLuUoR4z8xL9E2-Z6tDjt9Uw12lKiuUbWHM3_yHibMxcapsz3Mg
    id: obt_1MlLiJJITzLVzkSmg0YIZnCT
    livemode: false
    metadata: {}
    object: treasury.outbound_transfer
    returned_details:
      code: account_frozen
      transaction:
        amount: 1413853096
        balance_impact:
          cash: 3046195
          inbound_pending: 550878511
          outbound_pending: 786770760
        created: 1028554472
        currency: currency
        description: description
        financial_account: financial_account
        flow: null
        flow_type: credit_reversal
        id: obj_123
        livemode: true
        object: treasury.transaction
        status: open
        status_transitions:
          posted_at: null
          void_at: null
    statement_descriptor: transfer
    status: processing
    status_transitions:
      canceled_at: null
      failed_at: null
      posted_at: null
      returned_at: null
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
    tracking_details:
      type: ach
  treasury.received_credit:
    amount: 1234
    created: 1234567890
    currency: usd
    description: Stripe Test
    failure_code: null
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPz-vqAGMgZSNzJixFM6Nv0VWV7T_8jVIE_W8EW1gG-kYdu-UFUHBy2LI3OWjO3q1yADNGGAkOiD4NFfT7SLUdflrTKryQ
    id: rc_1MlLiKJITzLVzkSmZ2SULswc
    initiating_payment_method_details:
      billing_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: Jane Austen
      type: us_bank_account
      us_bank_account:
        bank_name: STRIPE TEST BANK
        last4: '6789'
        routing_number: '110000000'
    linked_flows:
      credit_reversal: null
      issuing_authorization: null
      issuing_transaction: null
      source_flow: null
      source_flow_type: null
    livemode: false
    network: ach
    object: treasury.received_credit
    reversal_details:
      deadline: 1678924800
      restricted_reason: null
    status: succeeded
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
  treasury.received_debit:
    amount: 54321
    created: 1234567890
    currency: usd
    description: Stripe Test
    failure_code: null
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    hosted_regulatory_receipt_url: >-
      https://rwashburne-agrippa-mydev.dev.stripe.me/regulatory-receipt/CBQaFwoVYWNjdF8xTVdsSERKSVR6TFZ6a1NtKPz-vqAGMgazSl8IJE46Nv1__KcJIlLl4WQgGil-YjxJglsJH_clFXE6AB7pu_yOKPAulPlxP5DTAFscALMtldl5CrYmUA
    id: rd_1MlLiKJITzLVzkSmjqj1yjA2
    initiating_payment_method_details:
      billing_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: Jane Austen
      type: us_bank_account
      us_bank_account:
        bank_name: STRIPE TEST BANK
        last4: '6789'
        routing_number: '110000000'
    linked_flows:
      debit_reversal: null
      inbound_transfer: null
      issuing_authorization: null
      issuing_transaction: null
      payout: null
    livemode: false
    network: ach
    object: treasury.received_debit
    reversal_details:
      deadline: 1678924800
      restricted_reason: null
    status: succeeded
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
  treasury.transaction:
    amount: -100
    balance_impact:
      cash: -100
      inbound_pending: 0
      outbound_pending: 100
    created: 1234567890
    currency: usd
    description: Jane Austen (6789) | Outbound transfer | transfer
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    flow: obt_1MlLiJJITzLVzkSmg0YIZnCT
    flow_type: outbound_transfer
    id: trxn_1MlLiEJITzLVzkSmdtaIuDk3
    livemode: false
    object: treasury.transaction
    status: open
    status_transitions:
      posted_at: null
      void_at: null
  treasury.transaction_entry:
    balance_impact:
      cash: 0
      inbound_pending: 0
      outbound_pending: -1000
    created: 1234567890
    currency: usd
    effective_at: 1234567890
    financial_account: fa_1MlLiEJITzLVzkSmGTgLnr26
    flow: obt_1MlLiJJITzLVzkSmg0YIZnCT
    flow_type: outbound_transfer
    id: trxne_1MlLiJJITzLVzkSm0HzmPEzZ
    livemode: false
    object: treasury.transaction_entry
    transaction: trxn_1MlLiEJITzLVzkSmdtaIuDk3
    type: outbound_transfer
  webhook_endpoint:
    api_version: null
    application: null
    created: 1234567890
    description: 'This is my webhook, I like it a lot'
    enabled_events:
      - charge.failed
      - charge.succeeded
    id: we_1MlLiDJITzLVzkSm0QU7AnxQ
    livemode: false
    metadata: {}
    object: webhook_endpoint
    status: enabled
    url: 'https://example.com/my/webhook/endpoint'
  account_notice:
    created: 1028554472
    deadline: null
    email:
      plain_text: plain_text
      recipient: recipient
      subject: subject
    id: obj_123
    linked_objects:
      capability: null
      issuing_dispute: null
    livemode: true
    metadata: null
    object: account_notice
    reason: issuing.account_closed_for_not_providing_business_model_clarification
    sent_at: null
  account_session:
    account: account
    client_secret: client_secret
    components:
      account_management:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          external_account_collection: true
      account_onboarding:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          external_account_collection: true
      balances:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          edit_payout_schedule: true
          external_account_collection: true
          instant_payouts: true
          standard_payouts: true
      disputes_list:
        enabled: true
        features:
          capture_payments: true
          destination_on_behalf_of_charge_management: true
          dispute_management: true
          refund_management: true
      documents:
        enabled: true
        features: {}
      financial_account:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          external_account_collection: true
          send_money: true
          transfer_balance: true
      financial_account_transactions:
        enabled: true
        features:
          card_spend_dispute_management: true
      issuing_card:
        enabled: true
        features:
          card_management: true
          card_spend_dispute_management: true
          cardholder_management: true
          spend_control_management: true
      issuing_cards_list:
        enabled: true
        features:
          card_management: true
          card_spend_dispute_management: true
          cardholder_management: true
          disable_stripe_user_authentication: true
          spend_control_management: true
      notification_banner:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          external_account_collection: true
      payment_details:
        enabled: true
        features:
          capture_payments: true
          destination_on_behalf_of_charge_management: true
          dispute_management: true
          refund_management: true
      payment_disputes:
        enabled: true
        features:
          destination_on_behalf_of_charge_management: true
          dispute_management: true
          refund_management: true
      payments:
        enabled: true
        features:
          capture_payments: true
          destination_on_behalf_of_charge_management: true
          dispute_management: true
          refund_management: true
      payouts:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          edit_payout_schedule: true
          external_account_collection: true
          instant_payouts: true
          standard_payouts: true
      payouts_list:
        enabled: true
        features: {}
      tax_registrations:
        enabled: true
        features: {}
      tax_settings:
        enabled: true
        features: {}
      instant_payouts_promotion:
        enabled: true
        features:
          disable_stripe_user_authentication: true
          external_account_collection: true
          instant_payouts: true
      payout_details:
        enabled: true
        features: {}
    expires_at: 833811170
    livemode: true
    object: account_session
  application:
    id: obj_123
    name: null
    object: application
  balance_settings:
    object: balance_settings
    payments:
      debit_negative_balances: null
      payouts:
        schedule:
          interval: null
        statement_descriptor: null
        status: disabled
        minimum_balance_by_currency: null
      settlement_timing:
        delay_days: 1647351405
  billing.alert:
    alert_type: usage_threshold
    id: obj_123
    livemode: true
    object: billing.alert
    status: null
    title: title
    usage_threshold:
      filters: null
      gte: 102680
      meter:
        created: 1028554472
        customer_mapping:
          event_payload_key: event_payload_key
          type: by_id
        default_aggregation:
          formula: sum
        display_name: display_name
        event_name: event_name
        event_time_window: null
        id: obj_123
        livemode: true
        object: billing.meter
        status: active
        status_transitions:
          deactivated_at: null
        updated: 234430277
        value_settings:
          event_payload_key: event_payload_key
      recurrence: one_time
  billing.alert_triggered:
    alert:
      alert_type: usage_threshold
      id: obj_123
      livemode: true
      object: billing.alert
      status: null
      title: title
      usage_threshold:
        filters: null
        gte: 102680
        meter:
          created: 1028554472
          customer_mapping:
            event_payload_key: event_payload_key
            type: by_id
          default_aggregation:
            formula: sum
          display_name: display_name
          event_name: event_name
          event_time_window: null
          id: obj_123
          livemode: true
          object: billing.meter
          status: active
          status_transitions:
            deactivated_at: null
          updated: 234430277
          value_settings:
            event_payload_key: event_payload_key
        recurrence: one_time
    created: 1028554472
    customer: customer
    livemode: true
    object: billing.alert_triggered
    value: '74648480.66666667'
  billing.credit_balance_summary:
    balances:
      - available_balance:
          monetary:
            currency: currency
            value: 111972721
          type: monetary
        ledger_balance:
          monetary:
            currency: currency
            value: 111972721
          type: monetary
    customer:
      created: 1028554472
      default_source: null
      description: null
      email: null
      id: obj_123
      livemode: true
      object: customer
      shipping: {}
    livemode: true
    object: billing.credit_balance_summary
  billing.credit_balance_transaction:
    created: 1028554472
    credit:
      amount:
        monetary:
          currency: currency
          value: 111972721
        type: monetary
      credits_application_invoice_voided:
        invoice: invoice
        invoice_line_item: invoice_line_item
      type: credits_application_invoice_voided
    credit_grant: credit_grant
    debit:
      amount:
        monetary:
          currency: currency
          value: 111972721
        type: monetary
      credits_applied:
        invoice: invoice
        invoice_line_item: invoice_line_item
      type: credits_applied
    effective_at: 247108043
    id: obj_123
    livemode: true
    object: billing.credit_balance_transaction
    test_clock: null
    type: null
  billing.credit_grant:
    amount:
      monetary:
        currency: currency
        value: 111972721
      type: monetary
    applicability_config:
      scope: {}
    category: paid
    created: 1028554472
    customer:
      created: 1028554472
      default_source: null
      description: null
      email: null
      id: obj_123
      livemode: true
      object: customer
      shipping: {}
    effective_at: null
    expires_at: null
    id: obj_123
    livemode: true
    metadata:
      undefined: metadata
    name: null
    object: billing.credit_grant
    test_clock: null
    updated: 234430277
    voided_at: null
  billing.meter:
    created: 1028554472
    customer_mapping:
      event_payload_key: event_payload_key
      type: by_id
    default_aggregation:
      formula: sum
    display_name: display_name
    event_name: event_name
    event_time_window: null
    id: obj_123
    livemode: true
    object: billing.meter
    status: active
    status_transitions:
      deactivated_at: null
    updated: 234430277
    value_settings:
      event_payload_key: event_payload_key
  billing.meter_event:
    created: 1028554472
    event_name: event_name
    identifier: identifier
    livemode: true
    object: billing.meter_event
    payload:
      undefined: payload
    timestamp: 55126294
  billing.meter_event_adjustment:
    cancel:
      identifier: null
    event_name: event_name
    livemode: true
    object: billing.meter_event_adjustment
    status: complete
    type: cancel
  billing.meter_event_summary:
    aggregated_value: 1264519369
    end_time: 1725551537
    id: obj_123
    livemode: true
    meter: meter
    object: billing.meter_event_summary
    start_time: 1573145462
  capital.financing_offer:
    account: account
    created: 1028554472
    expires_after: 2021972241
    id: obj_123
    livemode: true
    object: capital.financing_offer
    status: accepted
  capital.financing_summary:
    details:
      advance_amount: 1304981173
      advance_paid_out_at: null
      currency: currency
      current_repayment_interval:
        due_at: 1320896930
        paid_amount: null
        remaining_amount: 1811538239
      fee_amount: 490987313
      paid_amount: 1695771947
      remaining_amount: 1811538239
      repayments_begin_at: null
      withhold_rate: 65076826
    financing_offer: null
    object: capital.financing_summary
    status: null
  capital.financing_transaction:
    account: account
    created_at: 1369680106
    details:
      advance_amount: 1304981173
      currency: currency
      fee_amount: 490987313
      total_amount: 185007539
    financing_offer: null
    id: obj_123
    livemode: true
    object: capital.financing_transaction
    type: payment
    user_facing_description: null
  climate.order:
    amount_fees: 1211316940
    amount_subtotal: 1555417355
    amount_total: 1117121693
    canceled_at: null
    cancellation_reason: null
    certificate: null
    confirmed_at: null
    created: 1028554472
    currency: currency
    delayed_at: null
    delivered_at: null
    delivery_details:
      - delivered_at: 663949774
        location:
          city: null
          country: country
          latitude: null
          longitude: null
          region: null
        metric_tons: metric_tons
        registry_url: null
        supplier:
          id: obj_123
          info_url: info_url
          livemode: true
          locations:
            - city: null
              country: country
              latitude: null
              longitude: null
              region: null
          name: name
          object: climate.supplier
          removal_pathway: enhanced_weathering
    expected_delivery_year: 584813471
    id: obj_123
    livemode: true
    metadata:
      undefined: metadata
    metric_tons: '1158273248.6666667'
    object: climate.order
    product:
      created: 1028554472
      current_prices_per_metric_ton:
        undefined:
          amount_fees: 1211316940
          amount_subtotal: 1555417355
          amount_total: 1117121693
      delivery_year: null
      id: obj_123
      livemode: true
      metric_tons_available: '1213139418'
      name: name
      object: climate.product
      suppliers:
        - id: obj_123
          info_url: info_url
          livemode: true
          locations:
            - city: null
              country: country
              latitude: null
              longitude: null
              region: null
          name: name
          object: climate.supplier
          removal_pathway: enhanced_weathering
    product_substituted_at: null
    status: awaiting_funds
  climate.product:
    created: 1028554472
    current_prices_per_metric_ton:
      undefined:
        amount_fees: 1211316940
        amount_subtotal: 1555417355
        amount_total: 1117121693
    delivery_year: null
    id: obj_123
    livemode: true
    metric_tons_available: '1213139418'
    name: name
    object: climate.product
    suppliers:
      - id: obj_123
        info_url: info_url
        livemode: true
        locations:
          - city: null
            country: country
            latitude: null
            longitude: null
            region: null
        name: name
        object: climate.supplier
        removal_pathway: enhanced_weathering
  climate.supplier:
    id: obj_123
    info_url: info_url
    livemode: true
    locations:
      - city: null
        country: country
        latitude: null
        longitude: null
        region: null
    name: name
    object: climate.supplier
    removal_pathway: enhanced_weathering
  confirmation_token:
    created: 1028554472
    expires_at: null
    id: obj_123
    livemode: true
    object: confirmation_token
    payment_intent: null
    payment_method_options:
      card:
        cvc_token: null
    payment_method_preview:
      billing_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: null
        phone: null
        tax_id: null
      customer: null
      type: acss_debit
    return_url: null
    setup_future_usage: null
    setup_intent: null
    shipping:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      name: name
      phone: null
    use_stripe_sdk: true
  customer_session:
    client_secret: client_secret
    created: 1028554472
    customer:
      created: 1028554472
      default_source: null
      description: null
      email: null
      id: obj_123
      livemode: true
      object: customer
      shipping: {}
    expires_at: 833811170
    livemode: true
    object: customer_session
  deleted_application:
    deleted: true
    id: obj_123
    name: null
    object: application
  deleted_bank_account:
    deleted: true
    id: obj_123
    object: bank_account
  deleted_card:
    deleted: true
    id: obj_123
    object: card
  deleted_price:
    deleted: true
    id: obj_123
    object: price
  deleted_product_feature:
    deleted: true
    id: obj_123
    object: product_feature
  entitlements.active_entitlement:
    feature:
      active: true
      id: obj_123
      livemode: true
      lookup_key: lookup_key
      metadata:
        undefined: metadata
      name: name
      object: entitlements.feature
    id: obj_123
    livemode: true
    lookup_key: lookup_key
    object: entitlements.active_entitlement
  entitlements.active_entitlement_summary:
    customer: customer
    entitlements:
      data:
        - feature:
            active: true
            id: obj_123
            livemode: true
            lookup_key: lookup_key
            metadata:
              undefined: metadata
            name: name
            object: entitlements.feature
          id: obj_123
          livemode: true
          lookup_key: lookup_key
          object: entitlements.active_entitlement
      has_more: true
      object: list
      url: url
    livemode: true
    object: entitlements.active_entitlement_summary
  entitlements.feature:
    active: true
    id: obj_123
    livemode: true
    lookup_key: lookup_key
    metadata:
      undefined: metadata
    name: name
    object: entitlements.feature
  financial_connections.account_inferred_balance:
    as_of: 93102340
    current:
      undefined: 1126940025
    id: obj_123
    object: financial_connections.account_inferred_balance
  financial_connections.account_ownership:
    created: 1028554472
    id: obj_123
    object: financial_connections.account_ownership
    owners:
      data:
        - email: null
          id: obj_123
          name: name
          object: financial_connections.account_owner
          ownership: ownership
          phone: null
          raw_address: null
          refreshed_at: null
      has_more: true
      object: list
      url: url
  financial_connections.institution:
    countries:
      - countries
    features:
      balances:
        supported: true
      ownership:
        supported: true
      payment_method:
        supported: true
      transactions:
        supported: true
    id: obj_123
    livemode: true
    name: name
    object: financial_connections.institution
    routing_numbers:
      - routing_numbers
    status: active
    url: null
  financial_connections.transaction:
    account: account
    amount: 1413853096
    currency: currency
    description: description
    id: obj_123
    livemode: true
    object: financial_connections.transaction
    status: pending
    status_transitions:
      posted_at: null
      void_at: null
    transacted_at: 444205353
    transaction_refresh: transaction_refresh
    updated: 234430277
  forwarding.request:
    created: 1028554472
    id: obj_123
    livemode: true
    object: forwarding.request
    payment_method: payment_method
    replacements:
      - cardholder_name
    request_context:
      destination_duration: 2135692635
      destination_ip_address: destination_ip_address
    request_details:
      body: body
      headers:
        - name: name
          value: value
      http_method: POST
    response_details:
      body: body
      headers:
        - name: name
          value: value
      status: 892481550
    url: null
  fx_quote:
    created: 1028554472
    id: obj_123
    lock_duration: day
    lock_expires_at: null
    lock_status: active
    object: fx_quote
    rates:
      undefined:
        exchange_rate: 1381553532
        rate_details:
          base_rate: 1816487538
          duration_premium: 875827540
          fx_fee_rate: 817353018
          reference_rate: null
          reference_rate_provider: null
    to_currency: to_currency
    usage:
      payment:
        destination: null
        on_behalf_of: null
      transfer:
        destination: destination
      type: payment
  invoice_payment:
    amount_paid: null
    amount_requested: 1112626247
    created: 1028554472
    currency: currency
    id: obj_123
    invoice: invoice
    is_default: true
    livemode: true
    object: invoice_payment
    payment:
      type: charge
    status: status
    status_transitions:
      canceled_at: null
      paid_at: null
  invoice_rendering_template:
    created: 1028554472
    id: obj_123
    livemode: true
    metadata: null
    nickname: null
    object: invoice_rendering_template
    status: active
    version: 351608024
  issuing.credit_underwriting_record:
    application:
      application_method: in_person
      purpose: credit_limit_increase
      submitted_at: 2047729161
    created: 1028554472
    created_from: proactive_review
    credit_user:
      email: email
      name: name
    decided_at: null
    decision:
      application_rejected:
        reason_other_explanation: null
        reasons:
          - prior_or_current_legal_action
      credit_limit_approved:
        amount: 1413853096
        currency: currency
      credit_limit_decreased:
        amount: 1413853096
        currency: currency
        reason_other_explanation: null
        reasons:
          - insufficient_margin_ratio
      credit_line_closed:
        reason_other_explanation: null
        reasons:
          - insufficient_margin_ratio
      type: credit_limit_decreased
    decision_deadline: null
    id: obj_123
    livemode: true
    metadata: null
    object: issuing.credit_underwriting_record
    regulatory_reporting_file: null
    underwriting_exception:
      explanation: explanation
      original_decision_type: credit_line_closed
  issuing.dispute_settlement_detail:
    amount: 1413853096
    card: card
    created: 1028554472
    currency: currency
    dispute: dispute
    event_type: win
    id: obj_123
    livemode: true
    network: visa
    network_data:
      processing_date: null
    object: issuing.dispute_settlement_detail
    settlement: null
  issuing.fraud_liability_debit:
    amount: 1413853096
    balance_transaction: null
    created: 1028554472
    currency: currency
    dispute: dispute
    id: obj_123
    livemode: true
    object: issuing.fraud_liability_debit
  issuing.personalization_design:
    card_logo: null
    carrier_text:
      footer_body: null
      footer_title: null
      header_body: null
      header_title: null
    created: 1028554472
    id: obj_123
    livemode: true
    lookup_key: null
    metadata:
      undefined: metadata
    name: null
    object: issuing.personalization_design
    physical_bundle:
      features:
        card_logo: unsupported
        carrier_text: optional
        second_line: optional
      id: obj_123
      livemode: true
      name: name
      object: issuing.physical_bundle
      status: active
      type: custom
    preferences:
      is_default: true
      is_platform_default: null
    rejection_reasons:
      card_logo: null
      carrier_text: null
    status: rejected
  issuing.physical_bundle:
    features:
      card_logo: unsupported
      carrier_text: optional
      second_line: optional
    id: obj_123
    livemode: true
    name: name
    object: issuing.physical_bundle
    status: active
    type: custom
  issuing.token:
    card: card
    created: 1028554472
    device_fingerprint: null
    id: obj_123
    livemode: true
    network: mastercard
    network_updated_at: 791673624
    object: issuing.token
    status: requested
  margin:
    active: true
    created: 1028554472
    id: obj_123
    livemode: true
    metadata: null
    name: null
    object: margin
    percent_off: 1487902325
    updated: 234430277
  order:
    amount_subtotal: 1555417355
    amount_total: 1117121693
    application: null
    billing_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      email: null
      name: null
      phone: null
    client_secret: null
    created: 1028554472
    currency: currency
    customer: null
    description: null
    discounts: null
    id: obj_123
    ip_address: null
    livemode: true
    metadata: null
    object: order
    payment:
      payment_intent: null
      settings:
        application_fee_amount: null
        automatic_payment_methods:
          enabled: true
        payment_method_options: {}
        payment_method_types: null
        return_url: null
        statement_descriptor: null
        statement_descriptor_suffix: null
        transfer_data:
          amount: null
          destination:
            id: obj_123
            object: account
      status: null
    shipping_cost:
      amount_subtotal: 1555417355
      amount_tax: 1424534716
      amount_total: 1117121693
      shipping_rate: null
    shipping_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      name: null
      phone: null
    status: canceled
    total_details:
      amount_discount: 406046392
      amount_shipping: null
      amount_tax: 1424534716
  payment_attempt_record:
    amount_canceled:
      currency: currency
      value: 111972721
    amount_failed:
      currency: currency
      value: 111972721
    amount_guaranteed:
      currency: currency
      value: 111972721
    amount_requested:
      currency: currency
      value: 111972721
    created: 1028554472
    customer_details:
      customer: null
      email: null
      name: null
      phone: null
    customer_presence: null
    description: null
    id: obj_123
    livemode: true
    metadata:
      undefined: metadata
    object: payment_attempt_record
    payment_method_details:
      billing_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: null
        phone: null
      payment_method: null
      type: type
    payment_record: null
    reported_by: stripe
    shipping_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      name: null
      phone: null
    amount:
      currency: currency
      value: 111972721
    amount_authorized:
      currency: currency
      value: 111972721
    amount_refunded:
      currency: currency
      value: 111972721
    application: null
    processor_details:
      type: custom
  payment_intent_amount_details_line_item:
    discount_amount: null
    id: obj_123
    object: payment_intent_amount_details_line_item
    payment_method_options: {}
    product_code: null
    product_name: product_name
    quantity: 1285004149
    tax:
      total_tax_amount: 1109208903
    unit_cost: 472784472
    unit_of_measure: null
  payment_method_configuration:
    active: true
    application: null
    id: obj_123
    is_default: true
    livemode: true
    name: name
    object: payment_method_configuration
    parent: null
  payment_method_domain:
    amazon_pay:
      status: active
    apple_pay:
      status: active
    created: 1028554472
    domain_name: domain_name
    enabled: true
    google_pay:
      status: active
    id: obj_123
    klarna:
      status: active
    link:
      status: active
    livemode: true
    object: payment_method_domain
    paypal:
      status: active
  payment_record:
    amount_canceled:
      currency: currency
      value: 111972721
    amount_failed:
      currency: currency
      value: 111972721
    amount_guaranteed:
      currency: currency
      value: 111972721
    amount_requested:
      currency: currency
      value: 111972721
    created: 1028554472
    customer_details:
      customer: null
      email: null
      name: null
      phone: null
    customer_presence: null
    description: null
    id: obj_123
    latest_payment_attempt_record: null
    livemode: true
    metadata:
      undefined: metadata
    object: payment_record
    payment_method_details:
      billing_details:
        address:
          city: null
          country: null
          line1: null
          line2: null
          postal_code: null
          state: null
        email: null
        name: null
        phone: null
      payment_method: null
      type: type
    shipping_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      name: null
      phone: null
    amount:
      currency: currency
      value: 111972721
    amount_authorized:
      currency: currency
      value: 111972721
    amount_refunded:
      currency: currency
      value: 111972721
    application: null
    processor_details:
      type: custom
    reported_by: stripe
  privacy.redaction_job:
    created: 1028554472
    id: obj_123
    livemode: true
    object: privacy.redaction_job
    status: succeeded
    validation_behavior: null
  privacy.redaction_job_validation_error:
    code: invalid_file_purpose
    erroring_object:
      id: obj_123
      object_type: object_type
    id: obj_123
    message: message
    object: privacy.redaction_job_validation_error
  product_feature:
    entitlement_feature:
      active: true
      id: obj_123
      livemode: true
      lookup_key: lookup_key
      metadata:
        undefined: metadata
      name: name
      object: entitlements.feature
    id: obj_123
    livemode: true
    object: product_feature
  quote_line:
    applies_to:
      new_reference: null
      subscription_schedule: null
      type: new_reference
    billing_cycle_anchor: null
    cancel_subscription_schedule:
      cancel_at: line_starts_at
      invoice_now: null
      prorate: null
    ends_at:
      computed: null
      duration:
        interval: month
        interval_count: 797691627
      timestamp: null
      type: quote_acceptance_date
    id: obj_123
    object: quote_line
    proration_behavior: null
    set_schedule_end: null
    starts_at:
      computed: null
      line_ends_at:
        id: obj_123
      timestamp: null
      type: quote_acceptance_date
  quote_preview_invoice:
    account_country: null
    account_name: null
    account_tax_ids: null
    amount_due: 1424549491
    amount_overpaid: 149300825
    amount_paid: 1211022765
    amount_remaining: 1288530639
    amount_shipping: 1195466315
    application: null
    applies_to:
      new_reference: null
      subscription_schedule: null
      type: new_reference
    attempt_count: 394495715
    attempted: true
    automatic_tax:
      disabled_reason: null
      enabled: true
      liability:
        type: account
      provider: null
      status: null
    automatically_finalizes_at: null
    billing_reason: null
    collection_method: charge_automatically
    created: 1028554472
    currency: currency
    custom_fields: null
    customer_address:
      city: null
      country: null
      line1: null
      line2: null
      postal_code: null
      state: null
    customer_email: null
    customer_name: null
    customer_phone: null
    customer_shipping: {}
    customer_tax_exempt: null
    default_payment_method: null
    default_source: null
    default_tax_rates:
      - active: true
        country: null
        created: 1028554472
        description: null
        display_name: display_name
        effective_percentage: null
        flat_amount:
          amount: 1413853096
          currency: currency
        id: obj_123
        inclusive: true
        jurisdiction: null
        jurisdiction_level: null
        livemode: true
        metadata: null
        object: tax_rate
        percentage: 921832806
        rate_type: null
        state: null
        tax_type: null
    description: null
    discounts:
      - checkout_session: null
        customer: null
        end: null
        id: obj_123
        invoice: null
        invoice_item: null
        object: discount
        promotion_code: null
        start: 109757538
        subscription: null
        subscription_item: null
        source:
          coupon: null
          type: coupon
    due_date: null
    effective_at: null
    ending_balance: null
    footer: null
    from_invoice:
      action: action
      invoice: invoice
    id: obj_123
    issuer:
      type: account
    last_finalization_error:
      type: idempotency_error
    latest_revision: null
    lines:
      data:
        - amount: 1413853096
          currency: currency
          description: null
          discount_amounts: null
          discountable: true
          discounts:
            - checkout_session: null
              customer: null
              end: null
              id: obj_123
              invoice: null
              invoice_item: null
              object: discount
              promotion_code: null
              start: 109757538
              subscription: null
              subscription_item: null
              source:
                coupon: null
                type: coupon
          id: obj_123
          invoice: null
          livemode: true
          metadata:
            undefined: metadata
          object: line_item
          parent:
            invoice_item_details:
              invoice_item: invoice_item
              proration: true
              proration_details:
                credited_items:
                  invoice: invoice
                  invoice_line_items:
                    - invoice_line_items
              subscription: null
            subscription_item_details:
              invoice_item: null
              proration: true
              proration_details:
                credited_items:
                  invoice: invoice
                  invoice_line_items:
                    - invoice_line_items
              subscription: null
              subscription_item: subscription_item
            type: invoice_item_details
          period:
            end: 100571
            start: 109757538
          pretax_credit_amounts: null
          pricing:
            type: price_details
            unit_amount_decimal: null
          quantity: null
          subscription: null
          taxes: null
      has_more: true
      object: list
      url: url
    livemode: true
    metadata: null
    next_payment_attempt: null
    number: null
    object: quote_preview_invoice
    on_behalf_of: null
    parent:
      quote_details:
        quote: quote
      subscription_details:
        metadata: null
        subscription: subscription
      type: quote_details
    payment_settings:
      default_mandate: null
      payment_method_options:
        acss_debit: {}
        bancontact:
          preferred_language: fr
        card:
          request_three_d_secure: null
        customer_balance:
          funding_type: null
        konbini: {}
        sepa_debit: {}
        us_bank_account: {}
      payment_method_types: null
    period_end: 384656733
    period_start: 301041764
    post_payment_credit_notes_amount: 304272452
    pre_payment_credit_notes_amount: 630496199
    receipt_number: null
    rendering:
      amount_tax_display: null
      pdf:
        page_size: null
      template: null
      template_version: null
    shipping_cost:
      amount_subtotal: 1555417355
      amount_tax: 1424534716
      amount_total: 1117121693
      shipping_rate: null
    shipping_details: {}
    starting_balance: 2098247133
    statement_descriptor: null
    status: null
    status_transitions:
      finalized_at: null
      marked_uncollectible_at: null
      paid_at: null
      voided_at: null
    subscription: null
    subtotal: 2060319484
    subtotal_excluding_tax: null
    test_clock: null
    total: 110549828
    total_discount_amounts: null
    total_excluding_tax: null
    total_pretax_credit_amounts: null
    total_taxes: null
    webhooks_delivered_at: null
  quote_preview_subscription_schedule:
    application: null
    applies_to:
      new_reference: null
      subscription_schedule: null
      type: new_reference
    canceled_at: null
    completed_at: null
    created: 1028554472
    current_phase:
      end_date: 1725067410
      start_date: 1573629589
    customer:
      created: 1028554472
      default_source: null
      description: null
      email: null
      id: obj_123
      livemode: true
      object: customer
      shipping: {}
    default_settings:
      application_fee_percent: null
      billing_cycle_anchor: automatic
      billing_thresholds:
        amount_gte: null
        reset_billing_cycle_anchor: null
      collection_method: null
      default_payment_method: null
      description: null
      invoice_settings:
        account_tax_ids: null
        days_until_due: null
        issuer:
          type: account
      on_behalf_of: null
      transfer_data:
        amount_percent: null
        destination:
          id: obj_123
          object: account
    end_behavior: release
    id: obj_123
    livemode: true
    metadata: null
    object: quote_preview_subscription_schedule
    phases:
      - add_invoice_items:
          - discounts:
              - coupon: null
                discount: null
                promotion_code: null
            price: price
            quantity: null
            metadata: null
            period:
              end:
                type: min_item_period_end
              start:
                type: max_item_period_start
        application_fee_percent: null
        billing_cycle_anchor: null
        billing_thresholds:
          amount_gte: null
          reset_billing_cycle_anchor: null
        collection_method: null
        currency: currency
        default_payment_method: null
        description: null
        discounts:
          - coupon: null
            discount: null
            promotion_code: null
        end_date: 1725067410
        invoice_settings:
          account_tax_ids: null
          days_until_due: null
          issuer:
            type: account
        items:
          - billing_thresholds:
              usage_gte: null
            discounts:
              - coupon: null
                discount: null
                promotion_code: null
            metadata: null
            plan:
              active: true
              amount: null
              amount_decimal: null
              billing_scheme: tiered
              created: 1028554472
              currency: currency
              id: obj_123
              interval: month
              interval_count: 797691627
              livemode: true
              metadata: null
              meter: null
              nickname: null
              object: plan
              product: null
              tiers_mode: null
              transform_usage:
                divide_by: 1592560163
                round: down
              trial_period_days: null
              usage_type: licensed
            price: price
        metadata: null
        on_behalf_of: null
        proration_behavior: create_prorations
        start_date: 1573629589
        transfer_data:
          amount_percent: null
          destination:
            id: obj_123
            object: account
        trial_end: null
    released_at: null
    released_subscription: null
    status: active
    subscription: null
    test_clock: null
    billing_mode:
      type: classic
      flexible: {}
  tax.association:
    calculation: calculation
    id: obj_123
    object: tax.association
    payment_intent: payment_intent
    tax_transaction_attempts: null
  tax.calculation:
    amount_total: 1117121693
    currency: currency
    customer: null
    customer_details:
      address:
        city: null
        country: country
        line1: null
        line2: null
        postal_code: null
        state: null
      address_source: null
      ip_address: null
      tax_ids:
        - type: np_pan
          value: value
      taxability_override: customer_exempt
    expires_at: null
    id: null
    livemode: true
    object: tax.calculation
    ship_from_details:
      address:
        city: null
        country: country
        line1: null
        line2: null
        postal_code: null
        state: null
    shipping_cost:
      amount: 1413853096
      amount_tax: 1424534716
      tax_behavior: exclusive
      tax_code: tax_code
    tax_amount_exclusive: 1942751627
    tax_amount_inclusive: 1240333095
    tax_breakdown:
      - amount: 1413853096
        inclusive: true
        tax_rate_details:
          country: null
          flat_amount:
            amount: 1413853096
            currency: currency
          percentage_decimal: percentage_decimal
          rate_type: null
          state: null
          tax_type: null
        taxability_reason: taxable_basis_reduced
        taxable_amount: 403650130
    tax_date: 277611582
  tax.calculation_line_item:
    amount: 1413853096
    amount_tax: 1424534716
    id: obj_123
    livemode: true
    metadata: null
    object: tax.calculation_line_item
    product: null
    quantity: 1285004149
    reference: reference
    tax_behavior: exclusive
    tax_code: tax_code
  tax.form:
    corrected_by: null
    created: 1028554472
    filing_statuses:
      - effective_at: 247108043
        jurisdiction:
          country: country
          level: country
          state: null
        value: filed
    id: obj_123
    livemode: true
    object: tax.form
    payee:
      account: null
      external_reference: null
      type: account
    type: eu_dac7
  tax.registration:
    active_from: 1051736765
    country: country
    country_options: {}
    created: 1028554472
    expires_at: null
    id: obj_123
    livemode: true
    object: tax.registration
    status: active
  tax.settings:
    defaults:
      tax_behavior: null
      tax_code: null
      provider: stripe
    head_office:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
    livemode: true
    object: tax.settings
    status: active
    status_details: {}
  tax.transaction:
    created: 1028554472
    currency: currency
    customer: null
    customer_details:
      address:
        city: null
        country: country
        line1: null
        line2: null
        postal_code: null
        state: null
      address_source: null
      ip_address: null
      tax_ids:
        - type: np_pan
          value: value
      taxability_override: customer_exempt
    id: obj_123
    livemode: true
    metadata: null
    object: tax.transaction
    posted_at: 2008020787
    reference: reference
    reversal:
      original_transaction: null
    ship_from_details:
      address:
        city: null
        country: country
        line1: null
        line2: null
        postal_code: null
        state: null
    shipping_cost:
      amount: 1413853096
      amount_tax: 1424534716
      tax_behavior: exclusive
      tax_code: tax_code
    tax_date: 277611582
    type: reversal
  tax.transaction_line_item:
    amount: 1413853096
    amount_tax: 1424534716
    id: obj_123
    livemode: true
    metadata: null
    object: tax.transaction_line_item
    product: null
    quantity: 1285004149
    reference: reference
    reversal:
      original_line_item: original_line_item
    tax_behavior: exclusive
    tax_code: tax_code
    type: reversal
  terminal.reader_collected_data:
    created: 1028554472
    id: obj_123
    livemode: true
    magstripe:
      data: null
    object: terminal.reader_collected_data
    type: magstripe
  terminal.onboarding_link:
    link_options:
      apple_terms_and_conditions:
        allow_relinking: null
        merchant_display_name: merchant_display_name
    link_type: apple_terms_and_conditions
    object: terminal.onboarding_link
    on_behalf_of: null
    redirect_url: redirect_url
  billing.analytics.meter_usage:
    livemode: true
    object: billing.analytics.meter_usage
    refreshed_at: 41145896
    rows:
      has_more: false
      data:
        - dimensions: null
          ends_at: 1606329638
          id: obj_123
          meter: null
          object: billing.analytics.meter_usage_row
          starts_at: 2128381215
          value: 111972721
      total: 110549828
      url: url
  billing.analytics.meter_usage_row:
    dimensions: null
    id: obj_123
    object: billing.analytics.meter_usage_row
    ends_at: 1606329638
    meter: null
    starts_at: 2128381215
    value: 111972721
  payment_method_balance:
    as_of: 93102340
    balance:
      fr_meal_voucher:
        available: null
    livemode: true
    object: payment_method_balance
  delegated_checkout.requested_session:
    currency: usd
    customer: null
    fulfillment_details:
      address:
        city: null
        country: null
        line1: null
        line2: null
        postal_code: null
        state: null
      email: null
      fulfillment_options: null
      name: null
      phone: null
      selected_fulfillment_option:
        shipping:
          shipping_option: null
        type: type
    id: obj_123
    livemode: true
    object: delegated_checkout.requested_session
    amount_subtotal: 1555417355
    amount_total: 1117121693
    created_at: 1369680106
    expires_at: 833811170
    line_item_details:
      - description: null
        images: null
        key: key
        name: name
        quantity: 1285004149
        sku_id: sku_id
        unit_amount: 861435763
        amount_discount: 406046392
        amount_subtotal: 1555417355
    metadata: null
    order_details:
      order_status_url: null
      order_id: null
    payment_method: null
    seller_details: {}
    setup_future_usage: null
    shared_metadata: null
    shared_payment_issued_token: null
    status: completed
    total_details:
      amount_fulfillment: null
      amount_tax: null
      applicable_fees: null
      amount_items_discount: null
      amount_cart_discount: null
    updated_at: 295464393
    payment_method_preview:
      billing_details:
        address:
          city: city
          country: country
          line1: line1
          line2: null
          postal_code: postal_code
          state: state
        email: null
        name: null
        phone: null
      card:
        exp_month: 40417826
        exp_year: 1940618977
        last4: last4
      type: type
  identity.blocklist_entry:
    created: 1028554472
    disabled_at: null
    expires_at: null
    id: obj_123
    livemode: true
    object: identity.blocklist_entry
    status: active
    type: document
    verification_report: null
    verification_session: null
  transit_balance:
    balance:
      available: 733902135
      pending: 682587753
    created: 1028554472
    currency: usd
    livemode: true
    object: transit_balance
  issuing.program:
    created: 1028554472
    id: obj_123
    is_default: true
    metadata:
      key: metadata
    object: issuing.program
    platform_program: null
  balance_transfer:
    amount: 1413853096
    created: 1028554472
    currency: usd
    destination_balance:
      type: type
    hosted_regulatory_receipt_url: null
    id: obj_123
    livemode: true
    metadata:
      key: metadata
    object: balance_transfer
    source_balance:
      type: type
  radar.account_evaluation:
    created_at: 1369680106
    customer: customer
    events: null
    id: obj_123
    livemode: true
    object: radar.account_evaluation
    signals: {}
    type: type
  product_catalog.trial_offer:
    duration:
      relative:
        iterations: 1751585482
      type: relative
    end_behavior:
      transition:
        price: price
      type: transition
    id: obj_123
    livemode: true
    object: product_catalog.trial_offer
    price:
      active: true
      billing_scheme: tiered
      created: 1028554472
      currency: usd
      custom_unit_amount: null
      id: obj_123
      livemode: true
      lookup_key: null
      metadata:
        key: metadata
      nickname: null
      object: price
      product:
        active: true
        created: 1028554472
        description: null
        id: obj_123
        images:
          - images
        livemode: true
        marketing_features:
          - {}
        metadata:
          key: metadata
        name: name
        object: product
        package_dimensions: null
        shippable: null
        tax_code: null
        type: good
        updated: 234430277
        url: null
      recurring: null
      tax_behavior: null
      tiers_mode: null
      transform_quantity: null
      type: one_time
      unit_amount: null
      unit_amount_decimal: null
`;

const JsonViewer: React.FC<{ data: object }> = ({ data }) => (
  <pre style={styles.jsonViewer}>
    {JSON.stringify(data, null, 2)}
  </pre>
);

interface ResourceViewProps {
  resourceKey: string | null;
  resourceData: any;
}

const ResourceView: React.FC<ResourceViewProps> = ({ resourceKey, resourceData }) => {
  if (!resourceKey || !resourceData) {
    return (
      <div style={styles.resourceViewWelcome}>
        <h2>Welcome to Stripe Nexus</h2>
        <p>Select a resource from the list on the left to view its details.</p>
      </div>
    );
  }

  return (
    <div style={styles.resourceViewContainer}>
      <h2 style={styles.resourceViewHeader}>{resourceKey}</h2>
      <JsonViewer data={resourceData} />
    </div>
  );
};

interface SidebarProps {
  resourceKeys: string[];
  searchTerm: string;
  selectedResourceKey: string | null;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSelectResource: (key: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  resourceKeys,
  searchTerm,
  selectedResourceKey,
  onSearchChange,
  onSelectResource,
}) => (
  <div style={styles.sidebar}>
    <div style={styles.sidebarHeader}>
      <h1 style={styles.sidebarTitle}>Stripe Nexus</h1>
      <input
        type="text"
        placeholder="Search resources..."
        value={searchTerm}
        onChange={onSearchChange}
        style={styles.searchInput}
      />
    </div>
    <ul style={styles.resourceList}>
      {resourceKeys.length > 0 ? (
        resourceKeys.map((key) => (
          <li
            key={key}
            onClick={() => onSelectResource(key)}
            style={
              key === selectedResourceKey
                ? { ...styles.resourceListItem, ...styles.resourceListItemSelected }
                : styles.resourceListItem
            }
          >
            {key}
          </li>
        ))
      ) : (
        <li style={{...styles.resourceListItem, cursor: 'default'}}>No results found.</li>
      )}
    </ul>
  </div>
);


const StripeNexusView: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedResourceKey, setSelectedResourceKey] = useState<string | null>(null);

    const stripeData = useMemo(() => {
        try {
            const doc = yaml.load(stripeResourcesYAML) as any;
            return doc.striperesources || {};
        } catch (e) {
            console.error("Error parsing YAML:", e);
            return {};
        }
    }, []);

    const allResourceKeys = useMemo(() => Object.keys(stripeData).sort(), [stripeData]);

    const filteredResourceKeys = useMemo(() => {
        if (!searchTerm) {
            return allResourceKeys;
        }
        return allResourceKeys.filter(key =>
            key.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [allResourceKeys, searchTerm]);
    
    const handleSelectResource = useCallback((key: string) => {
        setSelectedResourceKey(key);
    }, []);

    const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value);
    }, []);
    
    const selectedResourceData = useMemo(() => {
        return selectedResourceKey ? stripeData[selectedResourceKey] : null;
    }, [selectedResourceKey, stripeData]);

    return (
        <div style={styles.container}>
            <Sidebar
                resourceKeys={filteredResourceKeys}
                searchTerm={searchTerm}
                selectedResourceKey={selectedResourceKey}
                onSearchChange={handleSearchChange}
                onSelectResource={handleSelectResource}
            />
            <main style={styles.mainContent}>
                <ResourceView 
                    resourceKey={selectedResourceKey}
                    resourceData={selectedResourceData}
                />
            </main>
        </div>
    );
};

const styles: { [key: string]: React.CSSProperties } = {
    container: {
        display: 'flex',
        height: '100vh',
        width: '100vw',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
        color: '#333',
        overflow: 'hidden',
    },
    sidebar: {
        width: '300px',
        borderRight: '1px solid #e0e0e0',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: '#f7f7f7',
        flexShrink: 0,
    },
    sidebarHeader: {
        padding: '1rem',
        borderBottom: '1px solid #e0e0e0',
    },
    sidebarTitle: {
        margin: '0 0 0.5rem 0',
        fontSize: '1.5rem',
    },
    searchInput: {
        width: '100%',
        padding: '0.5rem',
        borderRadius: '5px',
        border: '1px solid #ccc',
        boxSizing: 'border-box',
    },
    resourceList: {
        listStyle: 'none',
        padding: 0,
        margin: 0,
        overflowY: 'auto',
        flexGrow: 1,
    },
    resourceListItem: {
        padding: '0.75rem 1rem',
        cursor: 'pointer',
        borderBottom: '1px solid #eee',
        transition: 'background-color 0.2s',
        fontSize: '14px',
    },
    resourceListItemSelected: {
        backgroundColor: '#e0e7ff',
        color: '#3730a3',
        fontWeight: 600,
    },
    mainContent: {
        flexGrow: 1,
        overflowY: 'auto',
        padding: '1.5rem',
        backgroundColor: '#fff',
    },
    resourceViewContainer: {
        height: '100%',
    },
    resourceViewHeader: {
        marginTop: 0,
        marginBottom: '1rem',
        borderBottom: '2px solid #e0e0e0',
        paddingBottom: '0.5rem',
    },
    resourceViewWelcome: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        height: 'calc(100vh - 3rem)',
        color: '#777',
        textAlign: 'center',
    },
    jsonViewer: {
        backgroundColor: '#f4f4f4',
        border: '1px solid #ddd',
        borderRadius: '5px',
        padding: '1rem',
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-all',
        fontSize: '14px',
        color: '#333',
        maxHeight: 'calc(100vh - 120px)',
        overflow: 'auto',
    },
};

export default StripeNexusView;